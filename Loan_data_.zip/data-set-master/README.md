# data-set

use jupyter notebook and upload the data folder plus the loan_statement file 
This will contain the documentation of the model that has been desgned
