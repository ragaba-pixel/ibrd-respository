DROP TABLE  IF EXISTS 3rd_party;

CREATE TABLE `3rd_party` (
  `3rd_party_id` int(11) NOT NULL AUTO_INCREMENT,
  `sold_3rd_party` double DEFAULT NULL,
  `repaid_3rd_party` double DEFAULT NULL,
  `due_3rd_party` double DEFAULT NULL,
  PRIMARY KEY (`3rd_party_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS amount;

CREATE TABLE `amount` (
  `amount_id` int(11) NOT NULL AUTO_INCREMENT,
  `original_principle_amount` double DEFAULT NULL,
  `cancelled_amount` double DEFAULT NULL,
  `undisbursed_amount` double DEFAULT NULL,
  `disbursed_amount` double DEFAULT NULL,
  `repaid_id` int(11) NOT NULL,
  PRIMARY KEY (`amount_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS borrower;

CREATE TABLE `borrower` (
  `borrower_id` int(11) NOT NULL AUTO_INCREMENT,
  `borrower_name` varchar(200) NOT NULL,
  `borrower_date` date NOT NULL,
  PRIMARY KEY (`borrower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS date;

CREATE TABLE `date` (
  `date_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_repayment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_repayment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `agreement_signing_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `board_approval_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `effective_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `closed_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_disbursement_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`date_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS gurantor;

CREATE TABLE `gurantor` (
  `gurantor_id` int(11) NOT NULL AUTO_INCREMENT,
  `gurantor_country_code` varchar(100) NOT NULL,
  `gurantor_name` varchar(200) NOT NULL,
  PRIMARY KEY (`gurantor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS ibrd;

CREATE TABLE `ibrd` (
  `ibrd_id` int(11) NOT NULL AUTO_INCREMENT,
  `repaid_amount` double DEFAULT NULL,
  `due_amount` double DEFAULT NULL,
  PRIMARY KEY (`ibrd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS loan;

CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_number` varchar(100) NOT NULL,
  `borrower_id` int(11) NOT NULL,
  `loan_type` varchar(100) NOT NULL,
  `loan_status` varchar(200) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `amount_id` int(11) NOT NULL,
  `exchange_adjustment` double DEFAULT NULL,
  `currency_of_commitment` varchar(100) NOT NULL,
  PRIMARY KEY (`loan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS location;

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL AUTO_INCREMENT,
  `region` varchar(100) NOT NULL,
  `gurantor_id` int(11) NOT NULL,
  PRIMARY KEY (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




DROP TABLE  IF EXISTS login;

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `secondname` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `user_pass` varchar(200) NOT NULL,
  `user_type` varchar(200) NOT NULL,
  `user_status` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO login VALUES("9","osp","osp","pro","male","3a8e55937df0d596fca0943b924306c9","admin","1");
INSERT INTO login VALUES("22","agaba","Ronald","agaba","male","79ef2317eeecc97f8278ab56d673d9c3","admin","0");



DROP TABLE  IF EXISTS project;

CREATE TABLE `project` (
  `project_id` int(11) NOT NULL AUTO_INCREMENT,
  `project_name` varchar(200) NOT NULL,
  `date_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `borrower_id` int(11) DEFAULT NULL,
  `3rd_party_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




