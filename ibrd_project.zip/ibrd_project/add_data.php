<?php
	require_once('files/admin_header_files.php');
	if (empty($_SESSION['username'])) {
		echo '<div class="row">
		<div class="col-md-3">
		<h4></h4>
		</div>
		<div class="col-md-6 w3-padding w3-round-xlarge w3-center w3-red w3-padding" id="note1" style="font-size:20px;"><i class="fa fa-warning w3-padding" aria-hidden="true"></i>&nbsp;Please you are not allowed to visit this page
		<div class="loader"></div><br>Redirecting to Login Page...
		</div>
		<div class="col-md-3">
		<h4></h4>
		</div>
		</div>
		';
		header('refresh:3; url=index');
	}
?>
<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <div class="w3-green w3-padding" style="margin-top: 0; padding: 0;">
	  	<div class="">
	  	<?php if (isset($_SESSION['firstname']) || isset($_SESSION['secondname']) || isset($_SESSION['username']) || isset($_SESSION['user_type']) || isset($_SESSION['user_gender'])) { ?>
	  	<p>Users Online : 
			<?php 
			$user_online = mysqli_query($dbconn, "SELECT * FROM login WHERE user_status = 1");
			echo "<span class='w3-badge w3-white'>" .mysqli_num_rows($user_online)."</span>";
			echo "<hr>";
		?>
		</p>
		<?php 
			if (isset($_SESSION['user_id'])) {
				$user_id = $_SESSION['user_id'];
			$dee = mysqli_query($dbconn, "SELECT * FROM login WHERE user_id = '$user_id' LIMIT 1");
			}
		while ($row = mysqli_fetch_assoc($dee)) {
		echo "Username : "."<strong class='w3-text-white'>".$row['username']."</strong>"."<br>";
		/*echo "Full Names : "."<strong class='w3-text-white' style='text-transform:uppercase; text-align:center;'>".$row['user_firstname']." ".$row['user_secondname']."</strong>"."<br>";
		echo "Phone No : "."<strong class='w3-text-white'>".$row['user_phone']."</strong>"."<br>";*/
			}
		?>
	  	</div>
	  </div>
	   <?php include('files/admin_nav_files.php'); ?>
	</div>
<span onclick="openNav()" style="margin-left: 25px; cursor: pointer;"><i class="fa fa-home w3-text-blue w3-padding w3-card-4 w3-round-xlarge" aria-hidden="true"></i>&nbsp;&nbsp;</span>
<?php } ?>
<!-- total number of boys and girls from the database.. -->
<div class="row fluid-container">
	<div class="col-md-2">
	<h4></h4>
	</div>
	<div class="col-md-3">
	<h4 class="w3-center">DataBank</h4>
	<hr>
	<button class="open btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add Project</button>
	<button class="open_borrower btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add Borrower</button>
	<button class="open_ibrd btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add IBRD</button>
	<button class="open_guranter btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add Guranter</button>
	<button class="open_country btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add Country</button>
	<button class="open_date btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add Date</button>
	<button class="open_amount btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add Amount</button>
	<button class="open_loan btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add Loan</button>
	<button class="open_3rd_party btn btn-primary"><i class="fa fa-plus" aria-hidden="true"></i>&nbsp;&nbsp;Add 3rd Party</button>

	</div>
	<script>
		$(document).ready(function(){
			$(".open").click(function(){
				$('.pop-outer').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer').fadeOut('slow');
			});
		});
	</script>
	<!-- IBRD JQUERY CALL -->
	<script>
		$(document).ready(function(){
			$(".open_ibrd").click(function(){
				$('.pop-outer-ibrd').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-ibrd').fadeOut('slow');
			});
		});
	</script>
	<div class="col-md-3">
	<!-- <button class="open">Click to open popup</button> -->
	<div style="display: none;" class="pop-outer">
		<div class="pop-inner">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2 class="w3-center">Add Project</h2>
			<hr>
			<form method="POST" action="" class="form-inline">
				<?php require_once('files/errors.php'); ?>
			<div class="form-group">
			<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Username*:</label><br>
			<input type="text" name="username" class="form-control input-sm" placeholder="Enter Surname" value="<?php echo($username); ?>">	
			</div>
			<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Username*:</label><br>
		<input type="text" name="username" class="form-control input-sm" placeholder="Enter Surname" value="<?php echo($username); ?>">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Username*:</label><br>
		<input type="text" name="username" class="form-control input-sm" placeholder="Enter Surname" value="<?php echo($username); ?>">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Username*:</label><br>
		<input type="text" name="username" class="form-control input-sm" placeholder="Enter Surname" value="<?php echo($username); ?>">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Username*:</label><br>
		<input type="text" name="username" class="form-control input-sm" placeholder="Enter Surname" value="<?php echo($username); ?>">	
		</div>
		<center><button type="submit" class="w3-card-2 btn btn-success w3-text-white" name="add_user_register" style="font-size: 20px; color: blue; border-radius: 20px; width: 200px;" onclick="myLogin();">Register</button></center>
			</form>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<!-- Add IBRD form -->
	<div style="display: none;" class="pop-outer-ibrd">
		<div class="pop-inner-ibrd">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add IBRD</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<script>
		$(document).ready(function(){
			$(".open_country").click(function(){
				$('.pop-outer-country').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-country').fadeOut('slow');
			});
		});
	</script>
	<!-- Add Country Form form -->
	<div style="display: none;" class="pop-outer-country">
		<div class="pop-inner-country">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add Country</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<!-- Add IBRD form -->
	<script>
		$(document).ready(function(){
			$(".open_amount").click(function(){
				$('.pop-outer-amount').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-amount').fadeOut('slow');
			});
		});
	</script>
	<div style="display: none;" class="pop-outer-amount">
		<div class="pop-inner-amount">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add Amount</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<!-- Add IBRD form -->
	<script>
		$(document).ready(function(){
			$(".open_3rd_party").click(function(){
				$('.pop-outer-3rd-party').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-3rd-party').fadeOut('slow');
			});
		});
	</script>
	<div style="display: none;" class="pop-outer-3rd-party">
		<div class="pop-inner-3rd-party">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add 3rd-Party</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<!-- Add IBRD form -->
	<script>
		$(document).ready(function(){
			$(".open_borrower").click(function(){
				$('.pop-outer-borrower').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-borrower').fadeOut('slow');
			});
		});
	</script>
	<div style="display: none;" class="pop-outer-borrower">
		<div class="pop-inner-borrower">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add Borrower</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<!-- Add IBRD form -->
	<script>
		$(document).ready(function(){
			$(".open_guranter").click(function(){
				$('.pop-outer-gurantor').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-gurantor').fadeOut('slow');
			});
		});
	</script>
	<div style="display: none;" class="pop-outer-gurantor">
		<div class="pop-inner-gurantor">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add Gurantor</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<!-- Add IBRD form -->
	<script>
		$(document).ready(function(){
			$(".open_date").click(function(){
				$('.pop-outer-date').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-date').fadeOut('slow');
			});
		});
	</script>
	<div style="display: none;" class="pop-outer-date">
		<div class="pop-inner-date">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add Date</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	<!-- Add IBRD form -->
	<script>
		$(document).ready(function(){
			$(".open_loan").click(function(){
				$('.pop-outer-loan').fadeIn('slow');
			});
			$(".close").click(function(){
				$('.pop-outer-loan').fadeOut('slow');
			});
		});
	</script>
	<div style="display: none;" class="pop-outer-loan">
		<div class="pop-inner-loan">
			<button class="close" style="cursor: pointer; border-radius: 10px;">x</button><!-- Add project form -->
			<h2>Add Loan</h2>
			<p> ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
			tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
			quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
			consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
			cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
			proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			<!-- <button class="" style="background-color: #000; color: white; padding: 5px; width: 50%; border-radius: 8px;">login</button> -->
		</div>
	</div>
	</div>
	<div class="col-md-2">
		<h3></h3>
	</div>
</div>
<div class="row">
	<div class="col-md-2">
		<h4></h4>
	</div>
</div>
<?php
require_once('files/footer_files.php');
?>
<script>
	function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
</script>