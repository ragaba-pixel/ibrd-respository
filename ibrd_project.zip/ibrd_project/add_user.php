<?php
	require_once('files/admin_header_files.php');
	if (empty($_SESSION['username'])) {
		echo '<div class="row">
		<div class="col-md-3">
		<h4></h4>
		</div>
		<div class="col-md-6 w3-padding w3-round-xlarge w3-center w3-red w3-padding" id="note1" style="font-size:20px;"><i class="fa fa-warning w3-padding" aria-hidden="true"></i>&nbsp;Please you are not allowed to visit this page
		<div class="loader"></div><br>Redirecting to Login Page...
		</div>
		<div class="col-md-3">
		<h4></h4>
		</div>
		</div>
		';
		header('refresh:6; url=index');
	}
?>
<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <div class="w3-green w3-padding" style="margin-top: 0; padding: 0;">
	  	<div class="">
	  	<?php if (isset($_SESSION['firstname']) || isset($_SESSION['secondname']) || isset($_SESSION['username']) || isset($_SESSION['user_type']) || isset($_SESSION['user_gender'])) { ?>
	  	<p>Users Online : 
			<?php 
			$user_online = mysqli_query($dbconn, "SELECT * FROM login WHERE user_status = 1");
			echo "<span class='w3-badge w3-white'>" .mysqli_num_rows($user_online)."</span>";
			echo "<hr>";
		?>
		</p>
		<?php 
			if (isset($_SESSION['user_id'])) {
				$user_id = $_SESSION['user_id'];
			$dee = mysqli_query($dbconn, "SELECT * FROM login WHERE user_id = '$user_id' LIMIT 1");
			}
		while ($row = mysqli_fetch_assoc($dee)) {
		echo "Username : "."<strong class='w3-text-white'>".$row['username']."</strong>"."<br>";
		/*echo "Full Names : "."<strong class='w3-text-white' style='text-transform:uppercase; text-align:center;'>".$row['user_firstname']." ".$row['user_secondname']."</strong>"."<br>";
		echo "Phone No : "."<strong class='w3-text-white'>".$row['user_phone']."</strong>"."<br>";*/
			}
		?>
	  	</div>
	  </div>
	   <?php include('files/admin_nav_files.php'); ?>
	</div>
<span onclick="openNav()" style="margin-left: 25px; cursor: pointer;"><i class="fa fa-home w3-text-blue w3-padding w3-card-4 w3-round-xlarge" aria-hidden="true"></i>&nbsp;&nbsp;</span>
<?php } ?>
<div class="row">
	<div class="col-md-4">
		<h3></h3>
	</div>
	<div class="col-md-4">
	<fieldset style="margin-top: 50px; background: white;" class="w3-card-4">
	<div class="row">
	<div class="col-md-12" style="height: 100% auto;background-position: fixed;">
	<fieldset style="border-radius: 10px;" class="w3-white w3-border-green w3-card-4">
	<legend style="background-color: #6d670c;text-align: center;border-radius: 10px;color: #f1f1f1; width: 250px; box-shadow: rgb(200,100,0);" class="w3-green">Register</legend>
	<form action="" method="post" class="form-inline" enctype="multipart/form-data">
	<!-- form validation -->
	<?php
	//handling the sccessful login of the system user into the system.
	//using session to pick the user name and details if possible.
	?>
	<?php
	if (isset($_SESSION['reg_suc'])): ?>
		<div class="w3-padding w3-center w3-round-large w3-green" id="note2">
		<h3>
			<?php
				echo $_SESSION['reg_suc'];
				unset($_SESSION['reg_suc']);
				echo $_SESSION['re_suc'];
				unset($_SESSION['re_suc']);
				//header("refresh:5;url=index");
				//echo $_SESSION['suc_success'];
				//unset($_SESSION['suc_success']);
			?>
		</h3>
	</div>
	<?php elseif ($_SESSION['suc_logout']): ?>
		<div class="w3-padding w3-center w3-round-large w3-blue" id="note2">
		<h3>
			<?php
				echo $_SESSION['suc_logout'];
				unset($_SESSION['suc_logout']);
				echo $_SESSION['suc_log'];
				unset($_SESSION['suc_log']);
			?>
		</h3>
	</div>
	<?php endif ?>
	<?php require_once('files/errors.php'); ?>
		<div id="load" class="w3-center"></div>
		<!-- <div class="load_register_css" class="w3-center"></div> -->
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Username*:</label><br>
		<input type="text" name="username" class="form-control input-sm" placeholder="Enter Surname" value="<?php echo($username); ?>">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Firstname*:</label><br>
		<input type="text" name="firstname" class="form-control input-sm" placeholder="Enter Firstname" value="<?php echo($firstname); ?>">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Secondname*:</label><br>
		<input type="text" name="secondname" class="form-control input-sm" placeholder="Enter Secondname" value="<?php echo($secondname); ?>">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user-plus" aria-hidden="true"></i>&nbsp;&nbsp;Gender*:</label><br>
		<select name="gender" class="form-control">
			<option>male</option>
			<option>female</option>
		</select>
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-lock" aria-hidden="true"></i>&nbsp;&nbsp;user-type*:</label><br>
		<select name="user_type" class="form-control">
			<option>visitor</option>
			<option>admin</option>
		</select>
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-lock" aria-hidden="true"></i>&nbsp;&nbsp;Pass*:</label><br>
		<input type="password" name="user_pass_1" class="form-control input-sm" placeholder="Enter Password">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-lock" aria-hidden="true"></i>&nbsp;&nbsp;Confirm Pass*:</label><br>
		<input type="password" name="user_pass_2" class="form-control input-sm" placeholder="Enter Password">	
		</div>
	  	<div class="" style="margin-top: 20px;">
	  	<center><button type="submit" class="w3-card-2 btn btn-success w3-text-white" name="add_user_register" style="font-size: 20px; color: blue; border-radius: 20px; width: 200px;" onclick="myLogin();">Register</button></center>
	  </div>
  	</form>
	</fieldset>
	<!-- <center><button class="btn btn-default w3-card-2" name="register1"  style="font-size: 20px; color: ; width: 90%; margin-top: 5px;" >&nbsp;&nbsp;Create</button></center> -->
	</div>
	</div>
	</fieldset>
	</div>
	<div class="col-md-4">
		<h4></h4>
	</div>
</div>
<?php
require_once('files/footer_files.php');
?>
<script>
	function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
</script>