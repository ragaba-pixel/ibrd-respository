-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 13, 2020 at 04:27 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 5.6.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ibrd`
--

-- --------------------------------------------------------

--
-- Table structure for table `3rd_party`
--

CREATE TABLE `3rd_party` (
  `3rd_party_id` int(11) NOT NULL,
  `sold_3rd_party` double DEFAULT NULL,
  `repaid_3rd_party` double DEFAULT NULL,
  `due_3rd_party` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `amount`
--

CREATE TABLE `amount` (
  `amount_id` int(11) NOT NULL,
  `original_principle_amount` double DEFAULT NULL,
  `cancelled_amount` double DEFAULT NULL,
  `undisbursed_amount` double DEFAULT NULL,
  `disbursed_amount` double DEFAULT NULL,
  `repaid_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `borrower`
--

CREATE TABLE `borrower` (
  `borrower_id` int(11) NOT NULL,
  `borrower_name` varchar(200) NOT NULL,
  `borrower_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `date`
--

CREATE TABLE `date` (
  `date_id` int(11) NOT NULL,
  `first_repayment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_repayment_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `agreement_signing_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `board_approval_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `effective_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `closed_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_disbursement_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `gurantor`
--

CREATE TABLE `gurantor` (
  `gurantor_id` int(11) NOT NULL,
  `gurantor_country_code` varchar(100) NOT NULL,
  `gurantor_name` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ibrd`
--

CREATE TABLE `ibrd` (
  `ibrd_id` int(11) NOT NULL,
  `repaid_amount` double DEFAULT NULL,
  `due_amount` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `loan`
--

CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL,
  `loan_number` varchar(100) NOT NULL,
  `borrower_id` int(11) NOT NULL,
  `loan_type` varchar(100) NOT NULL,
  `loan_status` varchar(200) NOT NULL,
  `interest_rate` double DEFAULT NULL,
  `amount_id` int(11) NOT NULL,
  `exchange_adjustment` double DEFAULT NULL,
  `currency_of_commitment` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `location_id` int(11) NOT NULL,
  `region` varchar(100) NOT NULL,
  `gurantor_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `user_id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `firstname` varchar(200) NOT NULL,
  `secondname` varchar(200) NOT NULL,
  `gender` varchar(200) NOT NULL,
  `user_pass` varchar(200) NOT NULL,
  `user_type` varchar(200) NOT NULL,
  `user_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_id`, `username`, `firstname`, `secondname`, `gender`, `user_pass`, `user_type`, `user_status`) VALUES
(9, 'osp', 'osp', 'pro', 'male', '3a8e55937df0d596fca0943b924306c9', 'admin', 1),
(17, 'faith', 'faith', 'faith', 'female', 'ecee7df9bbac50b9b428483bfea1dd7c', 'visitor', 0),
(20, 'agaba', 'agaba', 'agaba', 'male', 'c4ca4238a0b923820dcc509a6f75849b', 'visitor', 0),
(21, 'h', 'h', 'h', 'male', '2510c39011c5be704182423e3a695e91', 'visitor', 0);

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `project_id` int(11) NOT NULL,
  `project_name` varchar(200) NOT NULL,
  `date_id` int(11) DEFAULT NULL,
  `loan_id` int(11) DEFAULT NULL,
  `borrower_id` int(11) DEFAULT NULL,
  `3rd_party_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `3rd_party`
--
ALTER TABLE `3rd_party`
  ADD PRIMARY KEY (`3rd_party_id`);

--
-- Indexes for table `amount`
--
ALTER TABLE `amount`
  ADD PRIMARY KEY (`amount_id`);

--
-- Indexes for table `borrower`
--
ALTER TABLE `borrower`
  ADD PRIMARY KEY (`borrower_id`);

--
-- Indexes for table `date`
--
ALTER TABLE `date`
  ADD PRIMARY KEY (`date_id`);

--
-- Indexes for table `gurantor`
--
ALTER TABLE `gurantor`
  ADD PRIMARY KEY (`gurantor_id`);

--
-- Indexes for table `ibrd`
--
ALTER TABLE `ibrd`
  ADD PRIMARY KEY (`ibrd_id`);

--
-- Indexes for table `loan`
--
ALTER TABLE `loan`
  ADD PRIMARY KEY (`loan_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`location_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`project_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `3rd_party`
--
ALTER TABLE `3rd_party`
  MODIFY `3rd_party_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `amount`
--
ALTER TABLE `amount`
  MODIFY `amount_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `borrower`
--
ALTER TABLE `borrower`
  MODIFY `borrower_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `date`
--
ALTER TABLE `date`
  MODIFY `date_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gurantor`
--
ALTER TABLE `gurantor`
  MODIFY `gurantor_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ibrd`
--
ALTER TABLE `ibrd`
  MODIFY `ibrd_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `loan`
--
ALTER TABLE `loan`
  MODIFY `loan_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `location_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `project_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
