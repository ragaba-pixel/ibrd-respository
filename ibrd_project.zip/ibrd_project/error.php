<?php
	require_once('files/header_files.php');
?>
<div class="row">
	<div class="col-md-3">
		<h4></h4>
	</div>
	<div class="col-md-6" style="background-image: url('images/ospslide.png');background-repeat: no-repeat;background-size: cover;height: 100% auto;background-position: fixed; margin-top: 100px;">
	<fieldset style="border-radius: 10px; background-image: url('images/ospslide.PNG'); background-repeat: no-repeat; background-position: fixed; background-size: cover;" class="w3-card-4 w3-border-blue w3-white">
	<legend style="background-color: #6d670c;text-align: center;border-radius: 10px;color: #f1f1f1; width: 250px;" class="w3-orange"><i class="fa fa-warning w3-padding" aria-hidden="true"></i>&nbsp;Error</legend>
	<h2>Ooops!! Looks like you are lost.</h2>
	<?php
	if (isset($_POST['load'])) {
		echo '<div class="loader"></div>';
		header("refresh:3;url=index");
	}
	?>	
	<form method="POST" action="" style="">
		<!-- <a href="index" class="btn btn-primary" type="submit" name="load"><i class="fa fa-backward" aria-hidden="true"></i>&nbsp;&nbsp;Login</a> -->
	<button type="submit" name="load" class="btn btn-success"><i class="fa fa-backward" aria-hidden="true"></i>&nbsp;&nbsp;Back</button>
	</form>
	</fieldset>
	</div>
	<div class="logout col-md-3">
		<h4></h4>
	</div>
</div>
<?php
require_once('files/footer_files.php');
?>
<!-- header("Location:?action=diseases"); to direct a user to the same page but of different items -->