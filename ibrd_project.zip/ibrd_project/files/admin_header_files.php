<?php
	require_once('files/connector.php');
	require_once('files/functions.php');
	error_reporting(null);
	?>
<!DOCTYPE html>
<html>
<head>
	<title>ibrd data</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" all>
	 <link rel="stylesheet" type="text/css" href="css/bootstrap.responsive.min.css" all>
	 <link rel="stylesheet" type="text/css" href="css/w3.css" all>
	 <link type="text/css" rel="stylesheet" href="css/font-awesome-4.6.3/css/font-awesome.min.css"/>
	 <link rel="stylesheet" type="text/css" href="css/main_data.css">
	 <link rel="stylesheet" type="text/css" href="css/slides-nav.css">
	 <link rel="stylesheet" type="text/css" href="css/model.css">
 	 <!-- <link rel="stylesheet" type="text/css" href="css/animation.osppro.css"/> -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/loader.js"></script>
 	<script src="js/webcam.min.js"></script>
 	<script src="js/canvasjs.min.js"> </script>
	 <style>
	 	.pop-outer{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner{
			background-color: #fff;
			width: 400px;
			/*height: 400px;*/
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding ibrd*/
		.pop-outer-ibrd{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-ibrd{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding country*/
		.pop-outer-country{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-country{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding amount*/
		.pop-outer-amount{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-amount{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding ibrd*/
		.pop-outer-3rd-party{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-3rd-party{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding borrower*/
		.pop-outer-borrower{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-borrower{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding gurantor*/
		.pop-outer-gurantor{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-gurantor{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding date*/
		.pop-outer-date{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-date{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
		/*adding borrower*/
		.pop-outer-loan{
			background-color: rgba(0,0,0,0.5);
			position: fixed;
			top: 0;
			left: 0;
			width: 100%;
			height: 100%;
		}
		.pop-inner-loan{
			background-color: #fff;
			width: 500px;
			height: 300px;
			padding: 25px;
			margin: 15% auto;
			border-radius: 8px;
		}
	 </style>
</head>
<?php
$ibrd_data = "<h2>IBRD DATA</h2>";
?>
<body>
	<div class="row">
		<div class="col-md-12 w3-padding jumbotron w3-green">
			<?php echo $ibrd_data; ?>
		</div>
	</div>