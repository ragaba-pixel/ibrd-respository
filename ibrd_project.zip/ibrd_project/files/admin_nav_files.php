<a href="dashboard" class="w3-hover-text-blue" onclick="fuction();"><i class="fa fa-list w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Dashboard</a>
<a href="add_user" class="w3-hover-text-blue" onclick="fuction();"><i class="fa fa-list w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Add User</a>
<a href="view_users" class="w3-hover-text-blue" onclick="fuction();"><i class="fa fa-street-view w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;View Users</a>
<a href="add_data" style="display: none;" class="w3-hover-text-blue" onclick="fuction();"><i class="fa fa-list w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Add Data</a>
<a href="view_data" class="w3-hover-text-blue" onclick="fuction();"><i class="fa fa-street-view w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;View Data</a>
<hr>
<a href="#" id="more"><i class="fa fa-glass w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;More</a>
<a href="statistics" style="display: none;" id="statistics" class="w3-hover-text-blue"><i class="fa fa-bar-chart w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Statistics</a>
<a href="settings" style="display: none;" id="settings" class="w3-hover-text-blue"><i class="fa fa-cogs w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Settings</a>
<a href="help" style="display: none;" id="help" class="w3-hover-text-blue"><i class="fa fa-question-circle w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Help</a>
<a href="index?logout='1'" style="display: none;" id="logout" class="w3-hover-text-red" onclick="return confirm('Do you really want to Logout?')"><i class="fa fa-power-off w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;sign out <?php echo "<div style='display:none;'>".$_SESSION['username']."</div>"; ?></a>
<script>
	$(document).ready(function(){
		$('#more').on('click', function(){
			$('#statistics').toggle(500);
			$('#logout').toggle(500);
		});
	});
</script>