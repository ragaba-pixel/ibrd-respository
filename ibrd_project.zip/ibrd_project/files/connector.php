<?php

//db connection......................
$dbconn = mysqli_connect("localhost","root",'','ibrd');
if (!$dbconn) {
echo mysqli_connect_error($dbconn);
exit();
}

?>