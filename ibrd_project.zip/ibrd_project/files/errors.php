<?php if (count($errors) > 0): ?> 
	<div class="w3-red w3-round-xlarge w3-padding w3-center" id="note1">
		<?php foreach ($errors as $error): ?> 
			<p><?php echo $error; ?></p>
		<?php endforeach ?>
	</div>
   <?php endif ?>