<?php
session_start();
require_once('files/connector.php');
//Register system user--------------------
$errors = array();
$username = "";
$firstname = "";
$secondname ="";
$gender ="";
$user_type = "";
$user_pass_1 = "";
$user_pass_2 = "";
if (isset($_POST['register'])) {
	$username = trim($_POST['username']);
	$firstname = trim($_POST['firstname']);
	$secondname =trim($_POST['secondname']);
	$user_type = trim($_POST['user_type']);
	$gender = @trim($_POST['gender']);
	$user_pass_1 = trim($_POST['user_pass_1']);
	$user_pass_2 = trim($_POST['user_pass_2']);
	if (empty($username)) {
		array_push($errors, "Username is required");
	}
	if (empty($firstname)) {
		array_push($errors, "Firstname is required");
	}
	if (empty($secondname)) {
		array_push($errors, "Secondname is required");
	}
	if (empty($user_pass_1)) {
		array_push($errors, "User password is required");
	}
	if ($user_pass_1 != $user_pass_2) {
		array_push($errors, "The two passwords do not match");
	}
	if (count($errors) == 0) {
		$user_pass = md5($user_pass_1);
		$sql = "INSERT INTO login(`user_id`, `username`, `firstname`, `secondname`, `gender`, `user_pass`, `user_type`, `user_status`) 
			VALUES(NULL,'$username','$firstname','$secondname','$gender','$user_pass','$user_type',0)";
						mysqli_query($dbconn,$sql);
			$_SESSION['username'] = $username;
			$_SESSION['firstname'] = $firstname;
			$_SESSION['secondname'] = $secondname;
			$_SESSION['gender'] = $gender;
			$_SESSION['user_type'] = $user_type;
			$_SESSION['re_suc'] = '<div class="loader_suc"></div>';
			$_SESSION['reg_suc'] = 'Registration Successful';
	}
}
//===========================================================================================
//===========================================================================================
//adding system user....
if (isset($_POST['add_user_register'])) {
	$username = trim($_POST['username']);
	$firstname = trim($_POST['firstname']);
	$secondname =trim($_POST['secondname']);
	$user_type = trim($_POST['user_type']);
	$gender = @trim($_POST['gender']);
	$user_pass_1 = trim($_POST['user_pass_1']);
	$user_pass_2 = trim($_POST['user_pass_2']);
	if (empty($username)) {
		array_push($errors, "Username is required");
	}
	if (empty($firstname)) {
		array_push($errors, "Firstname is required");
	}
	if (empty($secondname)) {
		array_push($errors, "Secondname is required");
	}
	if (empty($user_pass_1)) {
		array_push($errors, "User password is required");
	}
	if ($user_pass_1 != $user_pass_2) {
		array_push($errors, "The two passwords do not match");
	}
	if (count($errors) == 0) {
		$user_pass = md5($user_pass_1);
		$sql = "INSERT INTO login(`user_id`, `username`, `firstname`, `secondname`, `gender`, `user_pass`, `user_type`, `user_status`) 
			VALUES(NULL,'$username','$firstname','$secondname','$gender','$user_pass','$user_type',0)";
						mysqli_query($dbconn,$sql);
			$_SESSION['username'] = $username;
			$_SESSION['firstname'] = $firstname;
			$_SESSION['secondname'] = $secondname;
			$_SESSION['gender'] = $gender;
			$_SESSION['user_type'] = $user_type;
			$_SESSION['re_suc'] = '<div class="loader_suc"></div>';
			$_SESSION['reg_suc'] = 'Registration Successful';
	}
}
//**************************LOGIN SYSTEM USER===================
//user login details-----------------------
if (isset($_POST['username']) && isset($_POST['user_pass'])) {
	$username = trim($_POST['username']);
	$user_password = $_POST['user_pass'];
	if (empty($username) || empty($user_password)) {
		//array_push($errors, "User/Email or Pass is required");
		array_push($errors, "<div class='loader1 w3-center'></div><div class=''>User/Email or Pass is required</div>");
	}
	if (count($errors) == 0) {
		$user_password = md5($user_password);
		$sql = "SELECT * FROM login WHERE username ='$username' AND user_pass = '$user_password'";
		$result = mysqli_query($dbconn, $sql);
		if (mysqli_num_rows($result) == 1) {
			// log user in
			$row = mysqli_fetch_assoc($result);	
			$_SESSION['username'] = $row['username'];
			$_SESSION['user_id'] = $row['user_id'];
			$_SESSION['user_type'] = $row['user_type'];
			$_SESSION['secondname'] = $row['secondname'];
			$_SESSION['firstname'] = $row['firstname'];
			//$sql = "UPDATE login SET user_status = 1 WHERE user_name = '$user_name' AND user_pass = '$user_password'";
			$_SESSION['success'] = "Successful Login <strong class='w3-white w3-padding w3-round-large w3-text-green'>".$row['username']."</strong>";
			$sql = "UPDATE login SET user_status = 1 WHERE username = '$username' AND user_pass = '$user_password'";
			if($_SESSION['user_type']=='admin'){
				//echo '<div><img src="images/gifs/giff.gif" style="width:100%;"></div><br>Please Wait...';
				/*echo '<div class="loader"></div>';*/
				$_SESSION['suc'] = '<div class="loader_suc"></div>';
				$_SESSION['suc_success'] = "Login Successfully";
				header("refresh:5;url=dashboard");//olivia = 0783722674
			}
			else{
				//echo '<div><img src="images/gifs/giff.gif" style="width:100%;"></div><br>Please Wait...';
				//echo '<div class="loader"></div>';
				$_SESSION['suc'] = '<div class="loader_suc"></div>';
				$_SESSION['suc_success'] = "Login Successfully";
				header("refresh:5;url=visitor");
			}
			$re = mysqli_query($dbconn, $sql);
			//header('location: home.php');// redirect the user to home page	
			/*echo '<div>Successfully Login</div>';*/		
		}else{
			array_push($errors, "<div class='loader1 w3-center'></div><div class=''>Wrong username or Password</div>");
		}
	}
}
//===========================================================================================
//===========================================================================================
//===========================================================================================
//===========================================================================================
/*ADD STUDENT FOR SHORT-COURSE DATA DETAILS*/
/*short-courses*/
$std_id = "";
$std_surname="";
$std_othername = "";
$std_residence = "";
$std_nationality = "";
$std_sex = "";
$std_dob = "";
$std_phone = "";
$std_email = "";
$std_program = "";
$std_period = "";
$std_passport_photo = "";
$std_signature = "";
$parent_fullname = "";
$parent_phone = "";
$parent_address = "";
$relationship = "";
if (isset($_POST['add_short_course_std'])) {
	$std_surname= trim($_POST['std_surname']);
	$std_othername = trim($_POST['std_othername']);
	$std_residence = trim($_POST['std_residence']);
	$std_nationality = trim($_POST['std_nationality']);
	$std_sex = trim($_POST['std_sex']);
	$std_dob = trim($_POST['std_dob']);
	$std_phone = trim($_POST['std_phone']);
	$std_email = trim($_POST['std_email']);
	$std_program = trim($_POST['std_program']);
	$std_period = trim($_POST['std_period']);
	$std_passport_photo = trim($_FILES['std_passport_photo']['name']);
	$target_std_photo = "upload_short_course_std_photo/".basename($_FILES['std_passport_photo']['name']);
	$std_signature = trim($_FILES['std_signature']['name']);
	$target_std_sign = "upload_short_course_std_signature/".basename($_FILES['std_signature']['name']);
	$parent_fullname = trim($_POST['parent_fullname']);
	$parent_phone = trim($_POST['parent_phone']);
	$parent_address = trim($_POST['parent_address']);
	$relationship = trim($_POST['relationship']);
	if (empty($std_surname)) {
		array_push($errors, "Surname is required");
	}
	if (empty($std_othername)) {
		array_push($errors, "Othername is required");
	}
		if (empty($std_residence)) {
		array_push($errors, "Residence is required");
	}
	if (empty($std_nationality)) {
		array_push($errors, "Nationality is required");
	}
	if (count($errors) == 0) {
		$sql = "INSERT INTO short_course_std_details(std_surname,std_othername,std_residence,std_nationality,std_sex,std_dob,std_phone,std_email,std_program,std_period,std_passport_photo,std_signature,parent_fullname,parent_phone,parent_address,relationship) 
		VALUES('$std_surname','$std_othername','$std_residence','$std_nationality','$std_sex','$std_dob','$std_phone','$std_email','$std_program','$std_period','$std_passport_photo','$std_signature','$parent_fullname','$parent_phone','$parent_address','$relationship')";
		mysqli_query($dbconn,$sql);
		$_SESSION['std_surname'] = $std_surname;
		$_SESSION['std_othername'] = $std_othername;
		$_SESSION['std_residence'] = $std_residence;
		$_SESSION['std_sex'] = $std_sex;
		$_SESSION['std_dob'] = $std_dob;
		$_SESSION['std_phone'] = $std_phone;
		$_SESSION['std_email'] = $std_email;
		$_SESSION['std_program'] = $std_program;
		$_SESSION['std_period'] = $std_period;
		$_SESSION['std_passport_photo'] = $std_passport_photo;
		$_SESSION['std_signature'] = $std_signature;
		$_SESSION['parent_fullname'] = $parent_fullname;
		$_SESSION['parent_phone'] = $parent_phone;
		$_SESSION['parent_address'] = $parent_address;
		$_SESSION['relationship'] = $relationship;
		/////////////////////////////////////////////////////////

		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)


		//$number = ();
		$y = date('Y');
		$message = "Hi ".$std_surname.', You are enrolled at OSP I.T DIGITAL SOLUTIONS for a course : '.$std_program.', for the academic year. '.$y.' Thank You!';
		$nums = array("+256".$std_phone,"+256704487563");

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP : ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		/////////////////////////////////////////////////////////////


		if (move_uploaded_file($_FILES['std_passport_photo']['tmp_name'], $target_std_photo) && move_uploaded_file($_FILES['std_signature']['tmp_name'], $target_std_sign)) {
				$msg ="Image uploaded Successfully";
		}else{
					$msg ="There was a problem uploading image";
		}
		echo '<div class="loader"></div><br>File inserted correctely,Please Wait...';
		header("refresh:3;url=add_std.php");

	}

}

//===========================================================================================
//===========================================================================================
$std_photo =""; $std_sign =""; $reg_year = date('Y-m-d');
// ADD CERTIFICATE / DIPLOMA AND BACHELOR STUDENTS
if (isset($_POST['add_cert_dip_std_or_bachelor'])) {
	$std_surname= trim(ucfirst($_POST['std_surname']));
	$std_othername = trim(ucfirst($_POST['std_othername']));
	$std_nationality = trim(ucfirst($_POST['std_nationality']));
	$std_residence = trim(ucfirst($_POST['std_residence']));
	$std_gender = trim($_POST['std_gender']);
	$birth_day = trim($_POST['birth_day']);
	$birth_month = trim($_POST['birth_month']);
	$birth_year = trim($_POST['birth_year']);
	$std_phone = trim($_POST['std_phone']);
	$std_email = trim($_POST['std_email']);
	$std_level = trim($_POST['std_level']);
	$std_photo = trim($_FILES['std_photo']['name']);
	$target_C_D_B_photo = "upload_c_d_b_photos/".basename($_FILES['std_photo']['name']);
	$std_sign = trim($_FILES['std_sign']['name']);
	$target_sign_C_D_B = "upload_c_d_b_sign/".basename($_FILES['std_sign']['name']);
	/*$reg_year = trim($_POST['reg_year']);*/
	if (empty($std_surname)) {
		array_push($errors, "Surname is required");
	}
	if (empty($std_othername)) {
		array_push($errors, "Othername is required");
	}
		if (empty($std_residence)) {
		array_push($errors, "Residence is required");
	}
	if (empty($std_nationality)) {
		array_push($errors, "Nationality is required");
	}
	if (count($errors) == 0) {
		$sql = "INSERT INTO add_cert_or_diploma_student(`std_id`, `std_surname`, `std_othername`, `std_nationality`, `std_residence`, `std_gender`, `birth_day`, `birth_month`, `birth_year`, `std_phone`, `std_email`, `std_level`, `std_photo`, `std_sign`, `reg_year`) 
		VALUES(NULL,'$std_surname','$std_othername','$std_nationality','$std_residence','$std_gender','$birth_day','$birth_month','$birth_year','$std_phone','$std_email','$std_level','$std_photo','$std_sign','$reg_year')";
		mysqli_query($dbconn,$sql);
		$_SESSION['std_surname'] = $std_surname;
		$_SESSION['std_othername'] = $std_othername;
		$_SESSION['std_residence'] = $std_residence;
		$_SESSION['std_gender'] = $std_gender;
		$_SESSION['birth_day'] = $birth_day;
		$_SESSION['birth_month'] = $birth_month;
		$_SESSION['birth_year'] = $birth_year;
		$_SESSION['std_phone'] = $std_phone;
		$_SESSION['std_email'] = $std_email;
		$_SESSION['std_photo'] = $std_photo;
		$_SESSION['std_sign'] = $std_sign;
		/////////////////////////////////////////////////////////

		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)


		//$number = ();
		$y = date('Y');
		$message = "Hi ".$std_surname.', You are enrolled at OSP I.T DIGITAL SOLUTIONS for a course : '.$std_program.', for the academic year. '.$y.' Thank You!';
		$nums = array("+256".$std_phone,"+256704487563");

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP : ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		/////////////////////////////////////////////////////////////


		if (move_uploaded_file($_FILES['std_photo']['tmp_name'], $target_C_D_B_photo) && move_uploaded_file($_FILES['std_sign']['tmp_name'], $target_sign_C_D_B)) {
				$msg ="Image uploaded Successfully";
		}else{
					$msg ="There was a problem uploading image";
		}
		echo '<div class="loader"></div><br>File inserted correctely,Please Wait...';
		header("refresh:3;url=add_cert_or_dip.php");

	}

}

//===========================================================================================
//===========================================================================================
//===========================================================================================
/*internship student data.............details*/
$std_surname = "";
$std_othername = "";
$std_residence = "";
$std_nationality = "";
$std_sex = "";
$std_dob = "";
$std_phone = "";
$std_email = "";
$program = "";
$std_photo = "";
$std_sign = "";
$std_campus = "";
$course_n = "";
$level = "";
$reg_no = "";
$period = "";
if (isset($_POST['add_intern_std'])) {
	$std_surname = trim($_POST['std_surname']);
	$std_othername = trim($_POST['std_othername']);
	$std_residence = trim($_POST['std_residence']);
	$std_nationality = trim($_POST['std_nationality']);
	$std_sex = trim($_POST['std_sex']);
	$course_n = trim($_POST['course_n']);
	$level = trim($_POST['level']);
	$reg_no = trim($_POST['reg_no']);
	$std_dob = trim($_POST['std_dob']);
	$std_phone = trim($_POST['std_phone']);
	$std_email = trim($_POST['std_email']);
	$program = trim($_POST['program']);
	$target_intern_photos = "upload_internship_std_photos/".basename($_FILES['std_photo']['name']);
	$std_photo = trim($_FILES['std_photo']['name']);
	$target_intern_signs = "upload_internship_std_signature/".basename($_FILES['std_sign']['name']);
	$std_sign = trim($_FILES['std_sign']['name']);
	$std_campus = trim($_POST['std_campus']);
	$period = trim($_POST['period']);
	if (empty($std_surname)) {
		array_push($errors, "Surname is required");
	}
	if (empty($std_othername)) {
		array_push($errors, "Othername is required");
	}
	if (empty($std_residence)) {
		array_push($errors, "Residence is required");
	}
	if (empty($std_nationality)) {
		array_push($errors, "Nationality is required");
	}
	if (empty($std_dob)) {
		array_push($errors, "Residence is required");
	}
	if (empty($course_n)) {
		array_push($errors, "Pls, Provide student course name");
	}
	if (empty($period)) {
		array_push($errors, "Pls, Provide when a student is to start the internship");
	}
if (count($errors) == 0) {
	$query = "INSERT INTO internship_stds(std_surname,std_othername,std_residence,std_nationality,std_sex,std_dob,std_phone,std_email,program,std_photo,std_sign,std_campus,course_n,level,reg_no,period)
			VALUES('$std_surname','$std_othername','$std_residence','$std_nationality','$std_sex','$std_dob','$std_phone','$std_email','$program','$std_photo','$std_sign','$std_campus','$course_n','$level','$reg_no','$period')";
			mysqli_query($dbconn,$query);
		$_SESSION['std_surname'] = $std_surname;
		$_SESSION['std_othername'] = $std_othername;
		$_SESSION['std_residence'] = $std_residence;
		$_SESSION['level'] = $level;
		$_SESSION['reg_no'] = $reg_no;
		$_SESSION['std_nationality'] = $std_nationality;
		$_SESSION['std_sex'] = $std_sex;
		$_SESSION['std_dob'] = $std_dob;
		$_SESSION['std_phone'] = $std_phone;
		$_SESSION['std_email'] = $std_email;
		$_SESSION['program'] = $program;
		$_SESSION['course_n'] = $course_n;
		$_SESSION['std_photo'] = $std_photo;
		$_SESSION['std_sign'] = $std_sign;
		$_SESSION['std_campus'] = $std_campus;
		$_SESSION['period'] = $period;
		////////////////////////////////////////////////////////////////////
		///////////////////////INTERNSHIP STUDENT ENROLLMENT SMS PACKAGE///
		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)

	//$number = ();
		$y = date('Y');
		$message = "Hi ".$std_surname.', You are enrolled at OSP I.T DIGITAL SOLUTIONS for '.$program.' program year '.$y.'. Thank You!!';
		$nums = array("+256".$std_phone);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP : ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		//////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////
		if (move_uploaded_file($_FILES['std_photo']['tmp_name'], $target_intern_photos) && move_uploaded_file($_FILES['std_sign']['tmp_name'], $target_intern_signs)) {
				$msg ="Image uploaded Successfully";
		}else{
					$msg ="There was a problem uploading image";
		}
		echo '<div class="loader"></div><br>Internship student is added correctely,Please Wait...';
		header("refresh:3;url=internship.php");
}
}
//===========================================================================================
//===========================================================================================
							// 
				// OSP OFFER FOR STUDENTS.
//****************
//************************
//*******************************
if (isset($_POST['osp_std_offer'])) {
	$std_surname= trim($_POST['std_surname']);
	$std_othername = trim($_POST['std_othername']);
	$std_residence = trim($_POST['std_residence']);
	$std_nationality = trim($_POST['std_nationality']);
	$std_sex = trim($_POST['std_sex']);
	$std_dob = trim($_POST['std_dob']);
	$std_phone = trim($_POST['std_phone']);
	$std_email = trim($_POST['std_email']);
	$std_program = trim($_POST['std_program']);
	$std_period = trim($_POST['std_period']);
	$std_passport_photo = trim($_FILES['std_passport_photo']['name']);
	$target_std_photo = "upload_short_course_std_photo/".basename($_FILES['std_passport_photo']['name']);
	$std_signature = trim($_FILES['std_signature']['name']);
	$target_std_sign = "upload_short_course_std_signature/".basename($_FILES['std_signature']['name']);
	$parent_fullname = trim($_POST['parent_fullname']);
	$parent_phone = trim($_POST['parent_phone']);
	$parent_address = trim($_POST['parent_address']);
	$relationship = trim($_POST['relationship']);
	if (empty($std_surname)) {
		array_push($errors, "Surname is required");
	}
	if (empty($std_othername)) {
		array_push($errors, "Othername is required");
	}
		if (empty($std_residence)) {
		array_push($errors, "Residence is required");
	}
	if (empty($std_nationality)) {
		array_push($errors, "Nationality is required");
	}
	if (count($errors) == 0) {
		$sql = "INSERT INTO osp_offer_table(std_surname,std_othername,std_residence,std_nationality,std_sex,std_dob,std_phone,std_email,std_program,std_period,std_passport_photo,std_signature,parent_fullname,parent_phone,parent_address,relationship) 
		VALUES('$std_surname','$std_othername','$std_residence','$std_nationality','$std_sex','$std_dob','$std_phone','$std_email','$std_program','$std_period','$std_passport_photo','$std_signature','$parent_fullname','$parent_phone','$parent_address','$relationship')";
		mysqli_query($dbconn,$sql);
		$_SESSION['std_surname'] = $std_surname;
		$_SESSION['std_othername'] = $std_othername;
		$_SESSION['std_residence'] = $std_residence;
		$_SESSION['std_sex'] = $std_sex;
		$_SESSION['std_dob'] = $std_dob;
		$_SESSION['std_phone'] = $std_phone;
		$_SESSION['std_email'] = $std_email;
		$_SESSION['std_program'] = $std_program;
		$_SESSION['std_period'] = $std_period;
		$_SESSION['std_passport_photo'] = $std_passport_photo;
		$_SESSION['std_signature'] = $std_signature;
		$_SESSION['parent_fullname'] = $parent_fullname;
		$_SESSION['parent_phone'] = $parent_phone;
		$_SESSION['parent_address'] = $parent_address;
		$_SESSION['relationship'] = $relationship;
		/////////////////////////////////////////////////////////

		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)


		//$number = ();
		$y = date('Y');
		$message = "Hi ".$std_surname.' '.$std_othername.', You are enrolled at OSP for : '.$std_program.' Thank You!';
		$nums = array("+256".$std_phone);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP OFFER: ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		/////////////////////////////////////////////////////////////


		if (move_uploaded_file($_FILES['std_passport_photo']['tmp_name'], $target_std_photo) && move_uploaded_file($_FILES['std_signature']['tmp_name'], $target_std_sign)) {
				$msg ="Image uploaded Successfully";
		}else{
					$msg ="There was a problem uploading image";
		}
		echo '<div class="loader"></div><br>File inserted correctely,Please Wait...';
		header("refresh:3;url=osp_monthly_offer.php");

	}

}

//****************
//************************
//*******************************

//===========================================================================================
//===========================================================================================
//===========================================================================================
						//ADD STAFF MEMBERS
$staff_surname = "";
$staff_othername = "";
$staff_nationality = "";
$staff_sex = "";
$taff_dob = "";
$staff_phone = "";
$staff_email = "";
$staff_program = "";
$staff_photo = "";
$staff_signature = "";
if (isset($_POST['add_staff'])) {
	$staff_surname = trim($_POST['staff_surname']);
	$staff_othername = trim($_POST['staff_othername']);
	$staff_nationality = trim($_POST['staff_nationality']);
	$staff_sex = trim($_POST['staff_sex']);
	$staff_dob = trim($_POST['staff_dob']);
	$staff_phone = trim($_POST['staff_phone']);
	$staff_email = trim($_POST['staff_email']);
	$staff_program = trim($_POST['staff_program']);
	$target_staff_photo = "staff_passport_photos/".basename($_FILES['staff_photo']['name']);
	$staff_photo = trim($_FILES['staff_photo']['name']);
	$target_staff_sign = "staff_photo_sign/".basename($_FILES['staff_signature']['name']);
	$staff_signature = trim($_FILES['staff_signature']['name']);
	if (empty($staff_surname)) {
		array_push($errors, "Surname is required");
	}
	if (empty($staff_othername)) {
		array_push($errors, "Othername is required");
	}if (empty($staff_nationality)) {
		array_push($errors, "Nationality is required");
	}
	if (empty($staff_dob)) {
		array_push($errors, "Date of birth is required");
	}
	if (count($errors) == 0) {
		$save_staff = "INSERT INTO add_staff(staff_surname,staff_othername,staff_nationality,staff_sex,staff_dob,staff_phone,staff_email,staff_program,staff_photo,staff_signature) 
						VALUES('$staff_surname','$staff_othername','$staff_nationality','$staff_sex','$staff_dob','$staff_phone','$staff_email','$staff_program','$staff_photo','$staff_signature')";
		mysqli_query($dbconn,$save_staff);
		$_SESSION['staff_surname'] = $staff_surname;
		$_SESSION['staff_othername'] = $staff_othername;
		$_SESSION['staff_nationality'] = $staff_nationality;
		$_SESSION['staff_sex'] = $staff_sex;
		$_SESSION['staff_dob'] = $staff_dob;
		$_SESSION['staff_phone'] = $staff_phone;
		$_SESSION['staff_email'] = $staff_email;
		$_SESSION['staff_program'] = $staff_program;
		$_SESSION['staff_photo'] = $staff_photo;
		$_SESSION['staff_signature'] = $staff_signature;
		if (move_uploaded_file($_FILES['staff_photo']['tmp_name'], $target_staff_photo) && move_uploaded_file($_FILES['staff_signature']['tmp_name'], $target_staff_sign)) {
				$msg ="Image uploaded Successfully";
		}else{
					$msg ="There was a problem uploading image";
		}
		echo '<div class="loader"></div><br>Adding new staff is Successfully,Please Wait...';
		header("refresh:3;url=add_staff.php");
	}
}
#------------------------------------------------------------------
#----------------------------------------------------------------
					///fees payment for internship students.
$std_id = "";
$amount_paid = "";
$std_surname = "";
$std_phone = "";
if (isset($_POST['internship_payment'])) {
	$std_id = trim($_POST['std_id']);
	$amount_paid = trim($_POST['amount_paid']);
	$std_phone = trim($_POST['std_phone']);
	$std_surname = trim($_POST['std_surname']);
	if (empty($amount_paid)) {
		array_push($errors, "Please enter amount to pay");
	}
	if (empty($std_surname)) {
		array_push($errors, "Please student Surname");
	}
	if (empty($std_phone)) {
		array_push($errors, "Please enter student phone number");
	}
	if (count($errors) == 0) {
		$pay = "INSERT INTO student_payment_info(`fees_id`, `std_surname`, `std_phone`, `amount_paid`, `std_id`) 
				VALUES(NULL,'$std_surname','$std_phone','$amount_paid','$std_id')";
			mysqli_query($dbconn,$pay);
			$_SESSION['amount_paid'] = $amount_paid;
			$_SESSION['std_id'] = $std_id;
			$_SESSION['std_phone'] = $std_phone;
			$_SESSION['std_surname'] = $std_surname;
		////////////////////////////////////////////////////////////////////
		///////////////////////INTERNSHIP STUDENT ENROLLMENT SMS PACKAGE///
			//*****************************************************************************
			//*****************************************************************************
			//$internee_pay = mysqli_query($dbconn,"SELECT * FROM student_payment_info s , internship_stds i WHERE s.std_id = i.std_id LIMIT 1");
		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)

	//$number = ();
		//while ($row = mysqli_fetch_assoc($internee_pay)) {.//this is to start loop
			$y = date('Y');
		$message ='Internship payment UGx: '.number_format($amount_paid).' for '.$std_surname .'. Thank You!!';
		$nums = array("+256".$std_phone);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP I.T DIGITAL SOLUTIONS ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		///////}//this is to close the loop
		//////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////
		echo '<div class="loader"></div><br>Processing Payment,Please Wait...';
		header("refresh:3;url=internship_payment.php");
	}
}
#------------------------------------------------------------------
#----------------------------------------------------------------
					///fees payment for internship students.
$std_id = "";
$amount_paid = "";
if (isset($_POST['s_c_std_payment'])) {
	$std_id = trim($_POST['std_id']);
	$amount_paid = trim($_POST['amount_paid']);
	$amount_due = trim($_POST['amount_due']);
	$std_surname = trim($_POST['std_surname']);
	$std_phone = trim($_POST['std_phone']);
	//$std_program = trim($_POST['std_program']);
	if (empty($amount_paid)) {
		array_push($errors, "Please enter amount to pay");
	}
	if (empty($amount_due)) {
		array_push($errors, "Please provide actual amount a student to pay");
	}
	if (empty($std_phone)) {
		array_push($errors, "Please provide student/parent number");
	}
	if (empty($std_surname)) {
		array_push($errors, "Please provide student surname");
	}
	if (count($errors) == 0) {
		$pay_std = "INSERT INTO short_course_payment_info(`fees_id`, `std_surname`, `std_phone`, `amount_due`, `amount_paid`, `std_id`) 
				VALUES(NULL,'$std_surname','$std_phone','$amount_due','$amount_paid','$std_id')";
			mysqli_query($dbconn,$pay_std);
		echo '<div class="loader"></div><br>Processing Payment,Please Wait...';
		header("refresh:3;url=s_c_1234567.php");
		$_SESSION['amount_paid'] = $amount_paid;
		$_SESSION['amount_due'] = $amount_due;
		$_SESSION['std_id'] = $std_id;
		$_SESSION['std_phone'] = $std_phone;
		$_SESSION['std_surname'] = $std_surname;
		////////////////////////////////////////////////////////////////////
		///////////////////////shortcourse  student fees payment SMS PACKAGE///
			//*****************************************************************************
			//*****************************************************************************
			//$internee_pay = mysqli_query($dbconn,"SELECT * FROM student_payment_info s , internship_stds i WHERE s.std_id = i.std_id LIMIT 1");
		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)

	//$number = ();
		//while ($row = mysqli_fetch_assoc($internee_pay)) {.//this is to start loop
			$y = date('Y');
		$message ='Short-Course payment UGx: '.number_format($amount_paid).' for '.$std_surname .'. Thank You!!';
		$nums = array("+256".$std_phone);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP I.T DIGITAL SOLUTIONS ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		///////}//this is to close the loop
		//////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////
	}
}
#------------------------------------------------------------------
#----------------------------------------------------------------

///////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////
				///STUDENT SHORT-COURSE BALANCE HANDLING PAGE.
$std_id = "";
$amount_paid = "";
if (isset($_POST['s_payment'])) {
	$std_id = trim($_POST['std_id']);
	$amount_paid = trim($_POST['amount_paid']);
	$amount_due = trim($_POST['amount_due']);
	$std_surname = trim($_POST['std_surname']);
	$std_phone = trim($_POST['std_phone']);
	if (empty($amount_paid)) {
		array_push($errors, "Please enter amount to pay");
	}
	if (empty($amount_due)) {
		array_push($errors, "Please enter actual amount a student to pay ");
	}
	if (empty($std_surname)) {
		array_push($errors, "Please enter student surname");
	}
	if (empty($std_phone)) {
		array_push($errors, "Please enter student phone number");
	}
	if (count($errors) == 0) {
		$pay_std = "INSERT INTO short_course_payment_info(`fees_id`, `std_surname`, `std_phone`, `amount_due`, `amount_paid`, `std_id`) 
				VALUES(NULL,'$std_surname','$std_phone','$amount_due','$amount_paid','$std_id')";
			mysqli_query($dbconn,$pay_std);
		echo '<div class="loader"></div><br>Processing Payment,Please Wait...';
		header("refresh:3;url=s_c_payment_record.php");
		$_SESSION['amount_paid'] = $amount_paid;
		$_SESSION['amount_due'] = $amount_due;
		$_SESSION['std_id'] = $std_id;
		$_SESSION['std_phone'] = $std_phone;
		$_SESSION['std_surname'] = $std_surname;
		//********************************************************************
							//**************************************************
		//**********************************************************************
		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)

	//$number = ();
		//while ($row = mysqli_fetch_assoc($internee_pay)) {.//this is to start loop
			$y = date('Y');
		$message ='Short-Course payment UGx: '.number_format($amount_paid).' for '.$std_surname .'. Thank You!!';
		$nums = array("+256".$std_phone);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP I.T DIGITAL SOLUTIONS ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}


		//*********************************************************************
		//*********************************************************************
	}
}
#------------------------------------------------------------------
#----------------------------------------------------------------

//////////////////////
///////////..
///////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////
						//BULKY SMS
$surname = "";
$othername = "";
$phone_number = "";
$program = "";
//defining a function
function SMS(){
GLOBAL $dbconn;
if (isset($_POST['add_std_sms'])) {
	// defining the variables..
	$surname = trim($_POST['surname']);
	$othername = trim($_POST['othername']);
	$phone_number = trim($_POST['phone_number']);
	$program = trim($_POST['program']);
	$program_date = trim($_POST['program_date']);

	$sql1 = "INSERT INTO bulky_sms(`sms_id`, `surname`, `othername`, `phone_number`, `program`,`program_date`)
	VALUES(NULL,'$surname','$othername','$phone_number','$program','$program_date')";
	mysqli_query($dbconn, $sql1);
	echo '<div class="loader"></div><br>Inserting student details,Please Wait...';
		header("refresh:2;url=bulky_sms.php");
		$_SESSION['surname'] = $surname;
		$_SESSION['othername'] = $othername;
		$_SESSION['phone_number'] = $phone_number;
		$_SESSION['program'] = $program;
		$_SESSION['program_date'] = $program_date;
		//CALLING FOR BUILKY SMS FUNCTIONS.
			/////////////////////////////////////////////////////////

		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)


		//$number = ();
		$y = date('Y');
		$message = "Hi ".$surname.','.$program.' is starting on '.$program_date.' confirm yr reg. 4 more call 0704487563';
		$nums = array("+256".$phone_number);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP I.T DIGITAL SOLNS: ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}
}
}
//calling a function..
SMS();
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////


//STUDENT OSP OFFER, REGISTRATION INITIAL PAYMENTS.........................
#------------------------------------------------------------------
#----------------------------------------------------------------
					///fees payment for internship students.
$id = "";
$amount_paid = "";
$std_surname = "";
$std_phone = "";
if (isset($_POST['offer_payment'])) {
	$id = trim($_POST['id']);
	$amount_paid = trim($_POST['amount_paid']);
	$amount_due = trim($_POST['amount_due']);
	$std_phone = trim($_POST['std_phone']);
	$std_surname = trim($_POST['std_surname']);
	if (empty($amount_paid)) {
		array_push($errors, "Please enter amount to pay");
	}
	if (empty($std_surname)) {
		array_push($errors, "Please student Surname");
	}
	if (empty($std_phone)) {
		array_push($errors, "Please enter student phone number");
	}
	if (count($errors) == 0) {
		$pay = "INSERT INTO osp_offer_payment (`fees_id`, `std_surname`, `std_phone`, `amount_due`, `amount_paid`, `id`) 
				VALUES(NULL,'$std_surname','$std_phone','$amount_due','$amount_paid','$id')";
			mysqli_query($dbconn,$pay);
			$_SESSION['amount_due'] = $amount_due;
			$_SESSION['amount_paid'] = $amount_paid;
			$_SESSION['id'] = $id;
			$_SESSION['std_phone'] = $std_phone;
			$_SESSION['std_surname'] = $std_surname;
		////////////////////////////////////////////////////////////////////
		///////////////////////INTERNSHIP STUDENT ENROLLMENT SMS PACKAGE///
			//*****************************************************************************
			//*****************************************************************************
			//$internee_pay = mysqli_query($dbconn,"SELECT * FROM student_payment_info s , internship_stds i WHERE s.std_id = i.std_id LIMIT 1");
		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)

	//$number = ();
		//while ($row = mysqli_fetch_assoc($internee_pay)) {.//this is to start loop
			$y = date('Y');
		$message ='Registration Fee UGx: '.number_format($amount_paid).' for '.$std_surname .'. Thank You!!';
		$nums = array("+256".$std_phone);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP I.T DIGITAL SOLUTIONS ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		///////}//this is to close the loop
		//////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////
		echo '<div class="loader"></div><br>Processing Payment,Please Wait...';
		header("refresh:3;url=osp_offer_payment.php");
	}
}

//----------------Handling Invoices and system information
//add and remain
if (isset($_POST['add_invoice'])) {
	$c_surname = $_POST['c_surname'];
	$c_othername = $_POST['c_othername'];
	$company_name = $_POST['company_name'];
	$contact_no = $_POST['contact_no'];
	$location = $_POST['location'];
	$user_id = $_POST['user_id'];
	if (empty($c_surname)) {
		array_push($errors, "Please provide firstname");
	}
	if (empty($c_othername)) {
		array_push($errors, "Please provide second name");
	}
	if (empty($company_name)) {
		array_push($errors, "Please provide company name");
	}
	if (empty($contact_no)) {
		array_push($errors, "Please provide contact details");
	}
	if (count($errors) == 0) {
		$query = "INSERT INTO invoice (`invoice_id`, `c_surname`, `c_othername`, `company_name`, `contact_no`, `location`, `user_id`)
					VALUES(NULL,'$c_surname','$c_othername','$company_name','$contact_no','$location','$user_id')";
		mysqli_query($dbconn, $query);
		echo '<div class="loader"></div><br>Processing Invoice details,Please Wait...';
		echo mysqli_error($dbconn);
		header("refresh:3;url=invoice.php");
			$_SESSION['c_surname'] = $c_surname;
			$_SESSION['c_othername'] = $c_othername;
			$_SESSION['company_name'] = $company_name;
			$_SESSION['contact_no'] = $contact_no;
			$_SESSION['location'] = $location;
			$_SESSION['user_id'] = $user_id;
	}
}
//--------------------------------add and continue
if (isset($_POST['add_invoice1'])) {
	$c_surname = $_POST['c_surname'];
	$c_othername = $_POST['c_othername'];
	$company_name = $_POST['company_name'];
	$contact_no = $_POST['contact_no'];
	$location = $_POST['location'];
	$user_id = $_POST['user_id'];
	if (empty($c_surname)) {
		array_push($errors, "Please provide firstname");
	}
	if (empty($c_othername)) {
		array_push($errors, "Please provide second name");
	}
	if (empty($company_name)) {
		array_push($errors, "Please provide company name");
	}
	if (empty($contact_no)) {
		array_push($errors, "Please provide contact details");
	}
	if (count($errors) == 0) {
		$query = "INSERT INTO invoice (`invoice_id`, `c_surname`, `c_othername`, `company_name`, `contact_no`, `location`, `user_id`)
					VALUES(NULL,'$c_surname','$c_othername','$company_name','$contact_no','$location','$user_id')";
		mysqli_query($dbconn, $query);
		echo '<div class="loader"></div><br>Processing Invoice details,Please Wait...';
		//echo mysqli_error($dbconn);
		header("refresh:3;url=add_company_details.php");
			$_SESSION['c_surname'] = $c_surname;
			$_SESSION['c_othername'] = $c_othername;
			$_SESSION['company_name'] = $company_name;
			$_SESSION['contact_no'] = $contact_no;
			$_SESSION['location'] = $location;
			$_SESSION['user_id'] = $user_id;
	}
}
//+++++++++++++++++++++++++++++++++++
//-----------------------------------
	//=====ADD INVOICE PAYMENTS AND MORE...
$invoice_id = "";
$amount_paid = "";
if (isset($_POST['invoice_make_payments'])) {
	$invoice_id = trim($_POST['invoice_id']);
	$amount_paid = trim($_POST['amount_paid']);
	$amount_due = trim($_POST['amount_due']);
	$customer_name = trim($_POST['customer_name']);
	$contact_no = trim($_POST['contact_no']);
	//$std_program = trim($_POST['std_program']);
	if (empty($amount_paid)) {
		array_push($errors, "Please enter amount to pay");
	}
	if (empty($amount_due)) {
		array_push($errors, "Please provide actual amount of the invoice");
	}
	if (empty($contact_no)) {
		array_push($errors, "Please provide contact number");
	}
	if (empty($customer_name)) {
		array_push($errors, "Please provide customer name");
	}
	if (count($errors) == 0) {
		$pay_std = "INSERT INTO invoice_pay_money(`amount_id`, `customer_name`, `contact_no`, `amount_due`, `amount_paid`, `invoice_id`) 
				VALUES(NULL,'$customer_name','$contact_no','$amount_due','$amount_paid','$invoice_id')";
			mysqli_query($dbconn,$pay_std);
		echo '<div class="loader"></div><br>Processing Payment,Please Wait...';
		header("refresh:3;url=pay_invoice.php");
		$_SESSION['amount_paid'] = $amount_paid;
		$_SESSION['amount_due'] = $amount_due;
		$_SESSION['invoice_id'] = $invoice_id;
		$_SESSION['contact_no'] = $contact_no;
		$_SESSION['customer_name'] = $customer_name;
		////////////////////////////////////////////////////////////////////
		///////////////////////shortcourse  student fees payment SMS PACKAGE///
			//*****************************************************************************
			//*****************************************************************************
			//$internee_pay = mysqli_query($dbconn,"SELECT * FROM student_payment_info s , internship_stds i WHERE s.std_id = i.std_id LIMIT 1");
		require_once('AfricasTalkingGateway.php');
		// Specify your login credentials
		$username   = "osp";
		$apikey     = "bbb1d6451049f58e5510afbc14b26659670ade93064613a8d8b5056d1f1f24ec";
		// NOTE: If connecting to the sandbox, please use your sandbox login credentials
		// Specify the numbers that you want to send to in a comma-separated list
		// Please ensure you include the country code (+256 for Uganda in this case)

	//$number = ();
		//while ($row = mysqli_fetch_assoc($internee_pay)) {.//this is to start loop
			$y = date('Y');
		$message ='Short-Course payment UGx: '.number_format($amount_paid).' for '.$std_surname .'. Thank You!!';
		$nums = array("+256".$std_phone);

		{

		$recipients = "".implode(',', $nums);
		// And of course we want our recipients to know what we really do
		$message = "OSP I.T DIGITAL SOLUTIONS ".$message;

		// Create a new instance of our awesome gateway class
		$gateway    = new AfricasTalkingGateway($username, $apikey);
		// NOTE: If connecting to the sandbox, please add the sandbox flag to the constructor:
		/*************************************************************************************
					 ****SANDBOX****
		$gateway    = new AfricasTalkingGateway($username, $apiKey, "sandbox");
		**************************************************************************************/
		// Any gateway error will be captured by our custom Exception class below, 
		// so wrap the call in a try-catch block
		try 
		{ 
		  // Thats it, hit send and we'll take care of the rest. 
		  $results = $gateway->sendMessage($recipients, $message);
					
		  foreach($results as $result) {
			// status is either "Success" or "error message"
			//echo " Number: " .$result->number;
			//echo " Status: " .$result->status;
			//echo " MessageId: " .$result->messageId;
			//echo " Cost: "   .$result->cost."\n\n";
			echo '';
		  }
		}
		catch ( AfricasTalkingGatewayException $e )
		{
		  echo "Encountered an error while sending: ".$e->getMessage();
		}

		}

		///////}//this is to close the loop
		//////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////
	}
}//INVOICE PAYMENT IS DONE...


/*==========================================================================================*/
/*==========================================================================================*/
/*======================OSP EXPENDITURE DETAILS========================*/
if (isset($_POST['add_osp_expenditure'])) {
	$exp_category = $_POST['exp_category'];
	$exp_amount = $_POST['exp_amount'];
	$exp_reason = $_POST['exp_reason'];
	if (empty($exp_amount)) {
		array_push($errors, "Please enter amount");
	}
	if (empty($exp_reason)) {
		array_push($errors, "Please give reason");
	}

	if (count($errors) == 0) {
		$query = "INSERT INTO expenditure (`exp_id`, `exp_category`, `exp_amount`,`exp_reason`) 
					VALUES(NULL,'$exp_category','$exp_amount','$exp_reason')";
		mysqli_query($dbconn, $query);
		echo '<div class="loader"></div><br>Processing '.$exp_reason.' ,Please Wait...';
		//echo mysqli_error($dbconn);
		header("refresh:3;url=expenditure.php");
			$_SESSION['exp_category'] = $exp_category;
			$_SESSION['exp_amount'] = $exp_amount;
	}
}
/*==========================================================================================*/
/*==========================================================================================*/
/*==========================================================================================*/
?>
<?php
	if (isset($_GET['logout'])) {
	$username = $_SESSION['username'];
	$sql = "UPDATE login SET user_status = 0 WHERE username = '$username'";
	$re = mysqli_query($dbconn, $sql);
	session_destroy();
	unset($_SESSION['username']);
	//echo '<div><img src="images/gifs/giff.gif" style="width:100%;"></div><br>Please Wait,Loging Out...';
	$_SESSION['suc_logout'] = '<div class="loader_logout"></div>';
	header("refresh:6;url=index");
	$_SESSION['suc_log'] = "Loging out...";
}
// back code by Mr. Musitwa Joseph
/* backup the db OR just a table */
backup_tables($dbconn,'*');
function backup_tables( $con, $tables = '*')
{	
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = @mysqli_query($con, 'SHOW TABLES');
		while($row = mysqli_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	$return = "";
	//cycle through
	foreach($tables as $table)
	{
		$result = mysqli_query($con, 'SELECT * FROM '.$table);
		$num_fields = mysqli_num_fields($result);
		
		$return.= 'DROP TABLE  IF EXISTS '.$table.';';
		$row2 = mysqli_fetch_row(mysqli_query($con, 'SHOW CREATE TABLE '.$table));
		$return.= "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysqli_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j < $num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = str_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j < ($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";
	}
	
	//save file
	$handle = fopen('./_BACKUPS/db-backup-'.time().'-'.(md5(implode(',',$tables))).'.sql','w+');
	fwrite($handle,$return);
	fclose($handle);
}
//--------------------------------ADDING INVOICE DETAILS
if (isset($_POST['add_invoice_details'])) {
	@$invoice_id = trim($_POST['invoice_id']);
	$description1 = trim($_POST['description1']);
	$price1 = trim($_POST['price1']);
	$quantity1 = trim($_POST['quantity1']);
	$date_from1 = trim($_POST['date_from1']);
	$date_to1 = trim($_POST['date_to1']);

	$description2 = trim($_POST['description2']);
	$price2 = trim($_POST['price2']);
	$quantity2 = trim($_POST['quantity2']);
	$date_from2 = trim($_POST['date_from2']);
	$date_to2 = trim($_POST['date_to2']);

	$description3 = trim($_POST['description3']);
	$price3 = trim($_POST['price3']);
	$quantity3 = trim($_POST['quantity3']);
	$date_from3 = trim($_POST['date_from3']);
	$date_to3 = trim($_POST['date_to3']);

	$description4 = trim($_POST['description4']);
	$price4 = trim($_POST['price4']);
	$quantity4 = trim($_POST['quantity4']);
	$date_from4 = trim($_POST['date_from4']);
	$date_to4 = trim($_POST['date_to4']);
	if (empty($invoice_id)) {
		array_push($errors, "Please provide Company name");
	}
	$sql = "INSERT INTO invoice_pay(`inv_id`, `invoice_id`, `description`, `price`, `quantity`, `date_from`, `date_to`) 
			VALUES(NULL,'$invoice_id','$description1','$price1','$quantity1','$date_from1','$date_to1');";

	$sql .= "INSERT INTO invoice_pay (`inv_id`, `invoice_id`, `description`, `price`, `quantity`, `date_from`, `date_to`)
	VALUES(NULL,'$invoice_id','$description2','$price2','$quantity2','$date_from2','$date_to2');";

	$sql .= "INSERT INTO invoice_pay (`inv_id`, `invoice_id`, `description`, `price`, `quantity`, `date_from`, `date_to`)
	VALUES(NULL,'$invoice_id','$description3','$price3','$quantity3','$date_from3','$date_to3');";

	$sql .= "INSERT INTO invoice_pay (`inv_id`, `invoice_id`, `description`, `price`, `quantity`, `date_from`, `date_to`)
	VALUES(NULL,'$invoice_id','$description4','$price4','$quantity4','$date_from4','$date_to4');";
	//adding multiple values to the database...
	if (mysqli_multi_query($dbconn, $sql)) {
				echo "<div class='w3-green w3-padding w3-round-large' id='note2'> New records created Successfully</div>";
				header('refresh:3;url=invoice_payment.php');
	}else{
		echo "<div class='w3-red w3-round-large w3-padding' id='note1'> Error: ".$sql. "<br>".mysqli_error($dbconn)."</div>";
	}

}
?>