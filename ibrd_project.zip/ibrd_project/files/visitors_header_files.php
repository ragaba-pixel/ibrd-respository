<?php
	require_once('files/connector.php');
	require_once('files/functions.php');
	error_reporting(null);
	?>
<!DOCTYPE html>
<html>
<head>
	<title>ibrd data</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" all>
	 <link rel="stylesheet" type="text/css" href="css/bootstrap.responsive.min.css" all>
	 <link rel="stylesheet" type="text/css" href="css/w3.css" all>
	 <link type="text/css" rel="stylesheet" href="css/font-awesome-4.6.3/css/font-awesome.min.css"/>
	 <link rel="stylesheet" type="text/css" href="css/visitor_data.css">
	 <link rel="stylesheet" type="text/css" href="css/slides-nav.css">
	 <link rel="stylesheet" type="text/css" href="css/model.css">
 	 <!-- <link rel="stylesheet" type="text/css" href="css/animation.osppro.css"/> -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/loader.js"></script>
 	<script src="js/webcam.min.js"></script>
 	<script src="js/canvasjs.min.js"> </script>
	 
</head>
<?php
$ibrd_data = "<h2>IBRD DATA</h2>";
?>
<body>
	<div class="row">
		<div class="col-md-12 w3-padding jumbotron w3-green">
			<?php echo $ibrd_data; ?>
		</div>
	</div>