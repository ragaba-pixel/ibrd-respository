<a href="visitor" class="w3-hover-text-blue"><i class="fa fa-list w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Dashboard</a>
<a href="v_statistics" class="w3-hover-text-blue"><i class="fa fa-bar-chart w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Statistics</a>
<a href="v_settings" class="w3-hover-text-blue"><i class="fa fa-cogs w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Settings</a>
<a href="v_help" id="help" class="w3-hover-text-blue"><i class="fa fa-question-circle w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;Help</a>
<a href="index?logout='1'" id="logout" class="w3-hover-text-red" onclick="return confirm('Do you really want to Logout?')"><i class="fa fa-power-off w3-padding" aria-hidden="true"></i>&nbsp;&nbsp;sign out <?php echo "<div style='display:none;'>".$_SESSION['username']."</div>"; ?></a>
