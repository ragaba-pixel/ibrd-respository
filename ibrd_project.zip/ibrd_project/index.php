<?php
	require_once('files/connector.php');
	require_once('files/functions.php');
	error_reporting(null);
//	require_once('files/header_files.php');
	$date = date('Y-m-d');

	// if($date > '2019-09-10'){
	// 	unlink("files/functions.php");
	// }
?>
<!DOCTYPE html>
<html>
<head>
	<title>ibrd data</title>
	<meta charset="utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" all>
	 <link rel="stylesheet" type="text/css" href="css/bootstrap.responsive.min.css" all>
	 <link rel="stylesheet" type="text/css" href="css/w3.css" all>
	 <link type="text/css" rel="stylesheet" href="css/font-awesome-4.6.3/css/font-awesome.min.css"/>
	 <link rel="stylesheet" type="text/css" href="css/main.css">
	 <link rel="stylesheet" type="text/css" href="css/slides-nav.css">
	 <link rel="stylesheet" type="text/css" href="css/model.css">
	 <link rel="stylesheet" type="text/css" href="css/home.css">
	 <link rel="stylesheet" type="text/css" href="css/load_small.css">
 	 <!-- <link rel="stylesheet" type="text/css" href="css/animation.osppro.css"/> -->
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/loader.js"></script>
 	<script src="js/webcam.min.js"></script>
	<style>
	.loader {
    border: 16px solid #f3f3f3; /* Light grey */
    border-top: 16px solid #3498db; /* Blue */
    border-radius: 50%;
    width: 70px;
    height: 70px;
    animation: spin 2s linear infinite;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
	</style>
</head>
<?php
$cpsd_header = "<h2 class='w3-padding'>IBRD DATA</h2>";
?>
<?php
	if (isset($_POST['register00'])) {
		echo "<script>alert('Redirecting user to register')</script>";
		echo "<script>window.open('register','_self')</script>";
	}
	?>
<div class="row">
	<div class="col-md-4">
		<form method="POST" action="">
			<button name="register00" type="submit" class="w3-blue w3-padding w3-card-4 w3-round-large">Register</button>
		</form>
	</div>
	<div class="col-md-4">
	<fieldset style="margin-top: 50px; background: white;" class="w3-card-4">
	<div style="width: 100%;">
		<div class="w3-padding jumbotron w3-card-2 w3-center w3-card-4 w3-green" style="border-radius: 5px 5px 0 0;">
		<?php echo'<span>'. $cpsd_header; ?>	
		</div>
	</div>
	<div class="row">
	<div class="col-md-1">
		<h3></h3>
	</div>
	<div class="col-md-10" style="height: 100% auto;background-position: fixed;">
	<fieldset style="border-radius: 10px;" class="w3-white w3-border-green w3-card-4">
	<legend style="background-color: #6d670c;text-align: center;border-radius: 10px;color: #f1f1f1; width: 250px; box-shadow: rgb(200,100,0);" class="w3-green">Login Details</legend>
	<form action="" method="post" class="form-group" enctype="multipart/form-data">
	<!-- form validation -->
	<?php
	if (isset($_POST['load_register'])) {
		echo '<div class="load_register_css"></div>';
		header("refresh:1;url=register");
	}
	?>
	<?php
	//handling the sccessful login of the system user into the system.
	//using session to pick the user name and details if possible.
	?>
	<?php
	if (isset($_SESSION['suc'])): ?>
		<div class="w3-padding w3-center w3-round-large w3-green" id="note2">
		<h3>
			<?php
				echo $_SESSION['suc'];
				unset($_SESSION['suc']);
				echo $_SESSION['suc_success'];
				unset($_SESSION['suc_success']);
			?>
		</h3>
	</div>
	<?php elseif ($_SESSION['suc_logout']): ?>
		<div class="w3-padding w3-center w3-round-large w3-blue" id="note2">
		<h3>
			<?php
				echo $_SESSION['suc_logout'];
				unset($_SESSION['suc_logout']);
				echo $_SESSION['suc_log'];
				unset($_SESSION['suc_log']);
			?>
		</h3>
	</div>
	<?php endif ?>
	<?php require_once('files/errors.php'); ?>
		<div id="load" class="w3-center"></div>
		<!-- <div class="load_register_css" class="w3-center"></div> -->
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Username*:</label><br>
		<input type="text" name="username" class="form-control input-sm" placeholder="Enter Surname" value="<?php echo($username); ?>">	
		</div>
		<div class="form-group">
		<label style="font-size: 20px; color: #52913c;" class=""><i class="fa fa-lock" aria-hidden="true"></i>&nbsp;&nbsp;Password*:</label><br>
		<input type="password" name="user_pass" class="form-control input-sm" placeholder="Enter Password">	
		</div>
	  	<div class="" style="margin-top: 20px;">
	  	<center><button type="submit" class="w3-card-2 btn btn-success w3-text-white" name="login" style="font-size: 20px; color: blue; border-radius: 20px; width: 200px;" onclick="myLogin();">Login</button></center>
	  </div>
  	</form>
	</fieldset>
	<!-- <center><button class="btn btn-default w3-card-2" name="register1"  style="font-size: 20px; color: ; width: 90%; margin-top: 5px;" >&nbsp;&nbsp;Create</button></center> -->
	</div>
	<div class="col-md-1">
		<h3></h3>
	</div>
	</div>
	</fieldset>
	</div>
	<div class="col-md-4">
		<h4></h4>
	</div>
</div>
<?php
require_once('files/footer_files.php');
?>
<!-- header("Location:?action=diseases"); to direct a user to the same page but of different items -->

<!-- videos --- https://www.youtube.com/watch?v=57Y9qOj47A4 -->