// JavaScript Document
function _(x){
	return document.getElementById(x);
}
function check_username(){
	var u_name = _("uname").value;
	var status = _("status");				
	
	if(u_name == "") return false;
		
	status.innerHTML = 'loading...';//shows before or while match for username is taking place 
		
	var request = new XMLHttpRequest();
				
	request.open("POST", "usernames.php", true);
	request.setRequestHeader("Content-type", "application/x-www-form-urlencoded");			
	
	request.onreadystatechange = function() {
		if(request.readyState == 4 && request.status == 200) {
			//4    = The connection is complete, the data was sent or retrieved.
			//200  = The file has been retrieved and you are free to do something with it
			status.innerHTML = request.responseText;
		}
	}
	
	request.send("uname="+u_name);			
		
}
