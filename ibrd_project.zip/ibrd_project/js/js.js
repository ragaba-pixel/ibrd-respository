// JavaScript Document
$("#note1").delay(3000).fadeOut(2990);
$("#note2").delay(3000).fadeOut(3000);

