<?php
	require_once('files/admin_header_files.php');
	if (empty($_SESSION['username'])) {
		echo '<div class="row">
		<div class="col-md-3">
		<h4></h4>
		</div>
		<div class="col-md-6 w3-padding w3-round-xlarge w3-center w3-red w3-padding" id="note1" style="font-size:20px;"><i class="fa fa-warning w3-padding" aria-hidden="true"></i>&nbsp;Please you are not allowed to visit this page
		<div class="loader"></div><br>Redirecting to Login Page...
		</div>
		<div class="col-md-3">
		<h4></h4>
		</div>
		</div>
		';
		header('refresh:6; url=index');
	}
?>
<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <div class="w3-green w3-padding" style="margin-top: 0; padding: 0;">
	  	<div class="">
	  	<?php if (isset($_SESSION['firstname']) || isset($_SESSION['secondname']) || isset($_SESSION['username']) || isset($_SESSION['user_type']) || isset($_SESSION['user_gender'])) { ?>
	  	<p>Users Online : 
			<?php 
			$user_online = mysqli_query($dbconn, "SELECT * FROM login WHERE user_status = 1");
			echo "<span class='w3-badge w3-white'>" .mysqli_num_rows($user_online)."</span>";
			echo "<hr>";
		?>
		</p>
		<?php 
			if (isset($_SESSION['user_id'])) {
				$user_id = $_SESSION['user_id'];
			$dee = mysqli_query($dbconn, "SELECT * FROM login WHERE user_id = '$user_id' LIMIT 1");
			}
		while ($row = mysqli_fetch_assoc($dee)) {
		echo "Username : "."<strong class='w3-text-white'>".$row['username']."</strong>"."<br>";
		/*echo "Full Names : "."<strong class='w3-text-white' style='text-transform:uppercase; text-align:center;'>".$row['user_firstname']." ".$row['user_secondname']."</strong>"."<br>";
		echo "Phone No : "."<strong class='w3-text-white'>".$row['user_phone']."</strong>"."<br>";*/
			}
		?>
	  	</div>
	  </div>
	   <?php include('files/admin_nav_files.php'); ?>
	</div>
<span onclick="openNav()" style="margin-left: 25px; cursor: pointer;"><i class="fa fa-home w3-text-blue w3-padding w3-card-4 w3-round-xlarge" aria-hidden="true"></i>&nbsp;&nbsp;</span>
<?php } ?>
<script type="text/javascript">

$(document).ready(function () {

    $.ajax({
        type: "GET",
        url: "write.csv",
        dataType: "text",
        success: function (data) { processData(data); }
    });

    function processData(allText) {
        var allLinesArray = allText.split('\n');
        if (allLinesArray.length > 0) {
            var dataPoints = [];
            for (var i = 0; i <= allLinesArray.length - 1; i++) {
	        var rowData = allLinesArray[i].split(',');
	        if(rowData && rowData.length > 1)
	            dataPoints.push({ label: rowData[0], y: parseInt(rowData[1]) });
            }
            chart.options.data[0].dataPoints = dataPoints;
            chart.render();
        }
    }
            
    var chart = new CanvasJS.Chart("chartContainer", {
        theme: "theme2",
        title: {
            text: "IBRD DATA VIsualization using python Lib"
        },
        data: [
        {
            type: "column",
            dataPoints: []
        }
        ]
    });
            
});
</script>
<script type="text/javascript" src="canvasjs.min.js"></script>
<div id="chartContainer" style="height: 300px; width: 100%;"></div>
<?php
require_once('files/footer_files.php');
?>
<script>
	function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
</script>
<script>
  function printDiv() 
{
  var divToPrint=document.getElementById('DivIdToPrint');
  var newWin=window.open('','Print-Window');
  newWin.document.open();
  newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');
  newWin.document.close();
  setTimeout(function(){newWin.close();},10);
}
  </script>
  <!-- handling data -->
  <script>
	$(document).ready(function(){
		$('#statistics').on('click', function(){
			$('#dd').show(1000);
		});
	});
</script>