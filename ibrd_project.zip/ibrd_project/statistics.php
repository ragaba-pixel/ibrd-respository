<?php
	require_once('files/admin_header_files.php');
	if (empty($_SESSION['username'])) {
		echo '<div class="row">
		<div class="col-md-3">
		<h4></h4>
		</div>
		<div class="col-md-6 w3-padding w3-round-xlarge w3-center w3-red w3-padding" id="note1" style="font-size:20px;"><i class="fa fa-warning w3-padding" aria-hidden="true"></i>&nbsp;Please you are not allowed to visit this page
		<div class="loader"></div><br>Redirecting to Login Page...
		</div>
		<div class="col-md-3">
		<h4></h4>
		</div>
		</div>
		';
		header('refresh:6; url=index');
	}
?>
<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <div class="w3-green w3-padding" style="margin-top: 0; padding: 0;">
	  	<div class="">
	  	<?php if (isset($_SESSION['firstname']) || isset($_SESSION['secondname']) || isset($_SESSION['username']) || isset($_SESSION['user_type']) || isset($_SESSION['user_gender'])) { ?>
	  	<p>Users Online : 
			<?php 
			$user_online = mysqli_query($dbconn, "SELECT * FROM login WHERE user_status = 1");
			echo "<span class='w3-badge w3-white'>" .mysqli_num_rows($user_online)."</span>";
			echo "<hr>";
		?>
		</p>
		<?php 
			if (isset($_SESSION['user_id'])) {
				$user_id = $_SESSION['user_id'];
			$dee = mysqli_query($dbconn, "SELECT * FROM login WHERE user_id = '$user_id' LIMIT 1");
			}
		while ($row = mysqli_fetch_assoc($dee)) {
		echo "Username : "."<strong class='w3-text-white'>".$row['username']."</strong>"."<br>";
		/*echo "Full Names : "."<strong class='w3-text-white' style='text-transform:uppercase; text-align:center;'>".$row['user_firstname']." ".$row['user_secondname']."</strong>"."<br>";
		echo "Phone No : "."<strong class='w3-text-white'>".$row['user_phone']."</strong>"."<br>";*/
			}
		?>
	  	</div>
	  </div>
	   <?php include('files/admin_nav_files.php'); ?>
	</div>
<span onclick="openNav()" style="margin-left: 25px; cursor: pointer;"><i class="fa fa-home w3-text-blue w3-padding w3-card-4 w3-round-xlarge" aria-hidden="true"></i>&nbsp;&nbsp;</span>
<?php } ?>
<!-- data visualization.. -->
<div class="row">
	<div class="col-md-1">
		<h3></h3>
	</div>
<div class="col-md-10">
<hr>
</div>
<div class="col-md-1">
	<h4></h4>
</div>
</div>
<div class="row">
	<div class="col-md-12">
<?php

$row = 1;
if (($handle = fopen("ibrd.csv", "r")) !== FALSE) {
   
    echo '<table border="1">';
   
    while (($data = fgetcsv($handle, 1000, ";")) !== FALSE) {
        $num = count($data);
        if ($row == 1) {
            echo '<thead><tr>';
        }else{
            echo '<tr>';
        }
       
        for ($c=0; $c < $num; $c++) {
            //echo $data[$c] . "<br />\n";
            if(empty($data[$c])) {
               $value = "&nbsp;";
            }else{
               $value = $data[$c];
            }
            if ($row == 1) {
                echo '<th>'.$value.'</th>';
            }else{
                echo '<td>'.$value.'</td>';
            }
        }
       
        if ($row == 1) {
            echo '</tr></thead><tbody>';
        }else{
            echo '</tr>';
        }
        $row++;
    }
   
    echo '</tbody></table>';
    fclose($handle);
}
?>


<h3 style="text-align: center; color: blue;padding: 5px;"><i class="fa fa-table" aria-hidden="true"></i>&nbsp;&nbsp;IBRD DATASET <a class="btn btn-primary" href="visual_more_data_csv.php"><i class="fa fa-signal" aria-hidden="true"></i>&nbsp;&nbsp;Visualize Data</a></h3>
<?php

$infos = array();
$file_name = "csv_files/ibrd.csv";
if (($handle = fopen($file_name, "r")) !== FALSE) {
	echo '<div class="table-responsive">';
    echo '<table border="1" style="width: 100%; height:400px; margin-left:10px; text-align: left; border-collapse: collapse; overflow: scroll; box-shadow: 0px 1px 1px #000; margin-bottom: 10px;" class="table table-bordered table-hover w3-white"><thead style="scroll-behavior: smooth;margin-bottom: 100px;z-index:1;" class="w3-green">';
    echo '
    <th><i class="fa fa-table" aria-hidden="true"></i>&nbsp;&nbsp;End of Period</th>
    <th><i class="fa fa-pencil" aria-hidden="true"></i>&nbsp;&nbsp;Loan Number</th>
    <th><i class="fa fa-moon-o" aria-hidden="true"></i>&nbsp;&nbsp;Region</th>
    <th><i class="fa fa-flag" aria-hidden="true"></i>&nbsp;&nbsp;Country Code</th>
    <th><i class="fa fa-flag" aria-hidden="true"></i>&nbsp;&nbsp;Country</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Borrower</th>
    <th><i class="fa fa-flag" aria-hidden="true"></i>&nbsp;&nbsp;Guarantor Country Code</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Guarantor</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Loan Type</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Loan Status</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Interest Rate</th>
    <th><i class="fa fa-flag" aria-hidden="true"></i>&nbsp;&nbsp;Currency of Commitment</th>
    <th><i class="fa fa-navicon (alias)" aria-hidden="true"></i>&nbsp;&nbsp;Project ID</th>
    <th><i class="fa fa-navicon (alias)" aria-hidden="true"></i>&nbsp;&nbsp;Project Name</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Original Principal Amount</th>
    <th><i class="fa fa-money" aria-hidden="true"></i>&nbsp;&nbsp;Cancelled Amount</th>
    <th><i class="fa fa-money" aria-hidden="true"></i>&nbsp;&nbsp;Undisbursed Amount</th>
    <th><i class="fa fa-money" aria-hidden="true"></i>&nbsp;&nbsp;Disbursed Amount</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Repaid to IBRD</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Due to IBRD</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Exchange Adjument</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Borrowers Obligation</th>
    <th><i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;&nbsp;Sold 3rd Party</th>
    <th><i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;&nbsp;Repaid 3rd Party</th>
    <th><i class="fa fa-pencil-square-o" aria-hidden="true"></i>&nbsp;&nbsp;Due 3rd Party</th>
    <th><i class="fa fa-money" aria-hidden="true"></i>&nbsp;&nbsp;Loan Held</th>
    <th><i class="fa fa-money" aria-hidden="true"></i>&nbsp;&nbsp;First Repayment Date</th>
    <th><i class="fa fa-money" aria-hidden="true"></i>&nbsp;&nbsp;Last Repayment Date</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Agreement Signing Date</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Board Approval Date</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Effective Date(Most Recent)</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Closed Date(Most Recent)</th>
    <th><i class="fa fa-user" aria-hidden="true"></i>&nbsp;&nbsp;Last Disbursement Date</th>';
    echo '</thead>';
    while (($data = fgetcsv($handle, 0, ",")) !== FALSE) {
        echo '<tr>
        <td>' . $data[0] . '</td>
        <td>' . $data[1] . '</td>
        <td>' . $data[2] . '</td>
        <td>' . $data[3] . '</td>
        <td>' . $data[4] . '</td>
        <td>' . $data[5] . '</td>
        <td>' . $data[6] . '</td>
        <td>' . $data[7] . '</td>
        <td>' . $data[8] . '</td>
        <td>' . $data[9] . '</td>
        <td>' . $data[10] . '</td>
        <td>' . $data[11] . '</td>
        <td>' . $data[12] . '</td>
        <td>' . $data[13] . '</td>
        <td>' . $data[14] . '</td>
        <td>' . $data[15] . '</td>
        <td>' . $data[16] . '</td>
        <td>' . $data[17] . '</td>
        <td>' . $data[18] . '</td>
        <td>' . $data[19] . '</td>
        <td>' . $data[20] . '</td>
        <td>' . $data[21] . '</td>
        <td>' . $data[22] . '</td>
        <td>' . $data[23] . '</td>
        <td>' . $data[24] . '</td>
        <td>' . $data[25] . '</td>
        <td>' . $data[26] . '</td>
        <td>' . $data[27] . '</td>
        <td>' . $data[28] . '</td>
        <td>' . $data[29] . '</td>
        <td>' . $data[30] . '</td>
        <td>' . $data[31] . '</td>
        <td>' . $data[32] . '</td>
        </tr>';
        $infos[] = $data[0] . ',' . $data[1] . ',' . $data[2]. ',' . $data[3]. ',' . $data[4]. ',' . $data[5]. ',' . $data[6]. ',' . $data[7]. ',' . $data[8]. ',' . $data[9]. ',' . $data[10]. ',' . $data[11]. ',' . $data[12]. ',' . $data[13]. ',' . $data[14]. ',' . $data[15]. ',' . $data[16]. ',' . $data[17]. ',' . $data[18]. ',' . $data[19]. ',' . $data[20]. ',' . $data[21]. ',' . $data[22]. ',' . $data[23]. ',' . $data[24]. ',' . $data[25]. ',' . $data[26]. ',' . $data[27]. ',' . $data[28]. ',' . $data[29]. ',' . $data[30]. ',' . $data[31]. ',' . $data[32];
    }
    echo '</tbody></table>';
    echo '</div>';
    fclose($handle);
}

$fp = fopen('write.csv', 'w');

foreach ($infos as $info) {
    fputcsv($fp, array($info), ',', ' ');
}

fclose($fp);
/*
 * End of csvparser.php
 */
?>

<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ===========================PHP ARRAY FUNCTION========================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- adding csv file into array data using php -->
<?php

$filename = 'write.csv';

// The nested array to hold all the arrays
$the_big_array = []; 

// Open the file for reading
if (($h = fopen("{$filename}", "r")) !== FALSE) 
{
  // Each line in the file is converted into an individual array that we call $data
  // The items of the array are comma separated
  while (($data = fgetcsv($h, 1000, ",")) !== FALSE) 
  {
    // Each individual array is being pushed into the nested array
    $the_big_array[] = $data;		
  }

  // Close the file
  fclose($h);
}

// Display the code in a readable format
//echo "<pre>";
//var_dump($the_big_array);
//echo "</pre>";
?>
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ===========================PHP ARRAY FUNCTION========================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<!-- ====================================================================== -->
<?php
require_once('files/footer_files.php');
?>
<script>
	function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
</script>