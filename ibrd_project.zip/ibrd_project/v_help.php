<?php
	require_once('files/visitors_header_files.php');
	if (empty($_SESSION['username'])) {
		echo '<div class="row">
		<div class="col-md-3">
		<h4></h4>
		</div>
		<div class="col-md-6 w3-padding w3-round-xlarge w3-center w3-red w3-padding" id="note1" style="font-size:20px;"><i class="fa fa-warning w3-padding" aria-hidden="true"></i>&nbsp;Please you are not allowed to visit this page
		<div class="loader"></div><br>Redirecting to Login Page...
		</div>
		<div class="col-md-3">
		<h4></h4>
		</div>
		</div>
		';
		header('refresh:6; url=index');
	}
?>
<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <div class="w3-green w3-padding" style="margin-top: 0; padding: 0;">
	  	<div class="">
	  	<?php if (isset($_SESSION['firstname']) || isset($_SESSION['secondname']) || isset($_SESSION['username']) || isset($_SESSION['user_type']) || isset($_SESSION['user_gender'])) { ?>
	  	<p>Users Online : 
			<?php 
			$user_online = mysqli_query($dbconn, "SELECT * FROM login WHERE user_status = 1");
			echo "<span class='w3-badge w3-white'>" .mysqli_num_rows($user_online)."</span>";
			echo "<hr>";
		?>
		</p>
		<?php 
			if (isset($_SESSION['user_id'])) {
				$user_id = $_SESSION['user_id'];
			$dee = mysqli_query($dbconn, "SELECT * FROM login WHERE user_id = '$user_id' LIMIT 1");
			}
		while ($row = mysqli_fetch_assoc($dee)) {
		echo "Username : "."<strong class='w3-text-white'>".$row['username']."</strong>"."<br>";
		/*echo "Full Names : "."<strong class='w3-text-white' style='text-transform:uppercase; text-align:center;'>".$row['user_firstname']." ".$row['user_secondname']."</strong>"."<br>";
		echo "Phone No : "."<strong class='w3-text-white'>".$row['user_phone']."</strong>"."<br>";*/
			}
		?>
	  	</div>
	  </div>
	   <?php include('files/visitors_nav_files.php'); ?>
	</div>
<span onclick="openNav()" style="margin-left: 25px; cursor: pointer;"><i class="fa fa-home w3-text-blue w3-padding w3-card-4 w3-round-xlarge" aria-hidden="true"></i>&nbsp;&nbsp;</span>
<?php } ?>
<!-- total number of boys and girls from the database.. -->
<div class="row fluid-container">
	<div class="col-md-1">
		<h4></h4>
	</div>
	<div class="col-md-5">
		 <div id="piechart"></div>
		<?php
		//getting the total numbers of boys/men in the short-course programs.
		$boys = mysqli_query($dbconn, "SELECT * FROM short_course_std_details WHERE std_sex = 'Male'");
		$total_boys = mysqli_num_rows($boys);
		$girls = mysqli_query($dbconn, "SELECT * FROM short_course_std_details WHERE std_sex = 'Female'");
		$total_girls = mysqli_num_rows($girls);
		$total_stds = mysqli_query($dbconn, "SELECT * FROM short_course_std_details");
		$total = mysqli_num_rows($total_stds);
		?>
		<!-- pie chart -->
<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);
// Draw the chart and set the chart values
function drawChart() {
var data = google.visualization.arrayToDataTable([
['Task', 'Page visit per Day'],
['Boys/Male', '<?php print $total_boys; ?>'],
['Girls/Ladies', '<?php print $total_girls; ?>']
//['Total Students', '<?php print $total; ?>']
]);
// Optional; add a title and set the width and height of the chart
var options = {'title':'Total Boys/Men under Short-Course Program', 'width':550, 'height':400};
// Display the chart inside the <div> element with id="piechart"
var chart = new google.visualization.PieChart(document.getElementById('piechart'));
chart.draw(data, options);
}
</script>
<!-- bar graph -->
<div id="container" style="width: 550px; height: 400px; margin: 0 auto"></div>
<script type="text/javascript">
        google.charts.load('current', {packages:['corechart']});
    </script>
      <script language="JavaScript">
        function drawChart() {
            /* Define the chart to be drawn.*/
            var data = google.visualization.arrayToDataTable([
                ['Page Vist', 'Short-Course Students'],
                ['Boys/Men', <?php print $total_boys; ?>],
                ['Girls/Ladies', <?php print $total_girls; ?>],
            ]);
            var options = {
                title: 'Total Boys/Men under Short-Course Program',
                isStacked: true
            };
            /* Instantiate and draw the chart.*/
            var chart = new google.visualization.BarChart(document.getElementById('container'));
            chart.draw(data, options);
        }
        google.charts.setOnLoadCallback(drawChart);
    </script>
	</div>
	<div class="col-md-5">
		<!-- internship students details -->
		 <div id="piechart2"></div>
		<?php
		//getting the total numbers of boys/men in the short-course programs.
		$boyz = mysqli_query($dbconn, "SELECT * FROM internship_stds WHERE std_sex = 'Male'");
		$total_boyz = mysqli_num_rows($boyz);
		$girlz = mysqli_query($dbconn, "SELECT * FROM internship_stds WHERE std_sex = 'Female'");
		$total_girlz = mysqli_num_rows($girlz);
		$total_stdz = mysqli_query($dbconn, "SELECT * FROM internship_stds");
		$totaz = mysqli_num_rows($total_stdz);
		?>
		<!-- pie chart -->
<script type="text/javascript">
// Load google charts
google.charts.load('current', {'packages':['corechart']});
google.charts.setOnLoadCallback(drawChart);
// Draw the chart and set the chart values
function drawChart() {
var data = google.visualization.arrayToDataTable([
['Task', 'Page visit per Day'],
['Boys/Male', '<?php print $total_boyz; ?>'],
['Girls/Ladies', '<?php print $total_girlz; ?>']
//['Total Students', '<?php print $total; ?>']
]);
// Optional; add a title and set the width and height of the chart
var options = {'title':'Total Boys/Men under Internship Program', 'width':550, 'height':400};
// Display the chart inside the <div> element with id="piechart"
var chart = new google.visualization.PieChart(document.getElementById('piechart2'));
chart.draw(data, options);
}
</script>
<!-- bar graph -->
<div id="container2" style="width: 550px; height: 400px; margin: 0 auto"></div>
<script type="text/javascript">
        google.charts.load('current', {packages:['corechart']});
    </script>
      <script language="JavaScript">
        function drawChart() {
            /* Define the chart to be drawn.*/
            var data = google.visualization.arrayToDataTable([
                ['Page Vist', 'Internship Students'],
                ['Boys/Men', <?php print $total_boyz; ?>],
                ['Girls/Ladies', <?php print $total_girlz; ?>],
            ]);
            var options = {
                title: 'Total Boys/Men under Internship Program',
                isStacked: true
            };
            /* Instantiate and draw the chart.*/
            var chart = new google.visualization.BarChart(document.getElementById('container2'));
            chart.draw(data, options);
        }
        google.charts.setOnLoadCallback(drawChart);
    </script>
	</div>
	<div class="col-md-1">
		<h3></h3>
	</div>
</div>
<?php
require_once('files/footer_files.php');
?>
<script>
	function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
</script>