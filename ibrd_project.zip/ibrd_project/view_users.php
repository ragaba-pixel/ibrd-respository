<?php
	require_once('files/admin_header_files.php');
	if (empty($_SESSION['username'])) {
		echo '<div class="row">
		<div class="col-md-3">
		<h4></h4>
		</div>
		<div class="col-md-6 w3-padding w3-round-xlarge w3-center w3-red w3-padding" id="note1" style="font-size:20px;"><i class="fa fa-warning w3-padding" aria-hidden="true"></i>&nbsp;Please you are not allowed to visit this page
		<div class="loader"></div><br>Redirecting to Login Page...
		</div>
		<div class="col-md-3">
		<h4></h4>
		</div>
		</div>
		';
		header('refresh:6; url=index');
	}
?>
<div id="mySidenav" class="sidenav">
	  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
	  <div class="w3-green w3-padding" style="margin-top: 0; padding: 0;">
	  	<div class="">
	  	<?php if (isset($_SESSION['firstname']) || isset($_SESSION['secondname']) || isset($_SESSION['username']) || isset($_SESSION['user_type']) || isset($_SESSION['user_gender'])) { ?>
	  	<p>Users Online : 
			<?php 
			$user_online = mysqli_query($dbconn, "SELECT * FROM login WHERE user_status = 1");
			echo "<span class='w3-badge w3-white'>" .mysqli_num_rows($user_online)."</span>";
			echo "<hr>";
		?>
		</p>
		<?php 
			if (isset($_SESSION['user_id'])) {
				$user_id = $_SESSION['user_id'];
			$dee = mysqli_query($dbconn, "SELECT * FROM login WHERE user_id = '$user_id' LIMIT 1");
			}
		while ($row = mysqli_fetch_assoc($dee)) {
		echo "Username : "."<strong class='w3-text-white'>".$row['username']."</strong>"."<br>";
		/*echo "Full Names : "."<strong class='w3-text-white' style='text-transform:uppercase; text-align:center;'>".$row['user_firstname']." ".$row['user_secondname']."</strong>"."<br>";
		echo "Phone No : "."<strong class='w3-text-white'>".$row['user_phone']."</strong>"."<br>";*/
			}
		?>
	  	</div>
	  </div>
	   <?php include('files/admin_nav_files.php'); ?>
	</div>
<span onclick="openNav()" style="margin-left: 25px; cursor: pointer;"><i class="fa fa-home w3-text-blue w3-padding w3-card-4 w3-round-xlarge" aria-hidden="true"></i>&nbsp;&nbsp;</span>
<?php } ?>
<div class="row">
	<div class="col-md-2">
		<h3></h3>
	</div>
<div class="col-md-8">
<hr>
<button onclick='printDiv();' class="btn btn-primary w3-hover-blue w3-card-4" style="text-align: center;"><i class="fa fa-print" aria-hidden="true"></i>&nbsp;&nbsp;print</button><a href="stat_users" id="statistics" class="btn btn-primary w3-hover-blue w3-card-4" style="text-align: center;"><i class="fa fa-bar-chart" aria-hidden="true"></i>&nbsp;&nbsp;Statistics</a>
<div class="w3-padding w3-white w3-round-large" id='DivIdToPrint' id="dd">
<fieldset style="border-radius: 10px; background-image: url('images/ospslide.PNG'); background-repeat: no-repeat; background-position: fixed; background-size: cover;" class="w3-card-4 w3-border-blue">
<h3 style="text-align: center; color: blue;padding: 5px;">IBRD SYSTEM DATA USERS</h3>
<!-- ###################################################################### -->
<?php 
$staff = mysqli_query($dbconn, "SELECT * FROM login ORDER BY user_id DESC");
?>
<div class="table-responsive">
<form method="POST" action="">
<table style="width: 100%; text-align: left; border-collapse: collapse; overflow: scroll; box-shadow: 0px 1px 1px #000; margin-bottom: 10px;" class="table table-bordered table-hover" border="1">
<thead>
<tr>
<th class="w3-blue">#No.</th>
<th class="w3-blue">Username</th>
<th class="w3-blue">Name</th>
<th class="w3-blue">Gender</th>
<th class="w3-blue">User-Type</th>
<th class="w3-blue">User-Status</th>
<th class="w3-blue" colspan="1">Action.</th>
<?php //while($row = mysqli_fetch_array($search_result)): ?>
</tr>
<tr>
	
</tr>
</thead>
<tbody>
<?php while ($row = mysqli_fetch_array($staff)) { ?>
<tr class="" style="hover:#9BD5F5;">
<td><?php echo $row['user_id']; ?></td>
<td><?php echo $row['username']; ?></td>
<td><?php echo $row['firstname']." ".$row['secondname']; ?></td>
<td><?php echo $row['gender']; ?></td>
<td><?php echo $row['user_type']; ?></td>
<td><?php echo $row['user_status']; ?></td>
 <td>
 <!-- print student details... -->
  <a class="w3-blue w3-round" href="user_details?user_data=<?php echo $row['user_id']; ?>"><i class="fa fa-print"></i>&nbsp;&nbsp;</a>
  <a class="w3-red w3-round" href="delete_user?delete_user=<?php echo $row['user_id']; ?>"><i class="fa fa-step-forward"></i>&nbsp;&nbsp;</a>
</td>
</tr>
<?php } ?>
  </tbody>
</table>
<hr>
<div class="w3-blue w3-card-2">
<?php 
$select = mysqli_query($dbconn,"select * from login");
?>
<tr>
<th class="w3-padding">Total IBRD Data User(s) : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="badge w3-white w3-padding"><?php echo mysqli_num_rows($select); ?></span></th>
</tr>
</div>
</form>
</div>
</fieldset>
</div>
</div>
<div class="col-md-2">
	<h4></h4>
</div>
</div>
<?php
require_once('files/footer_files.php');
?>
<script>
	function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}
/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft = "0";
}
</script>
<script>
  function printDiv() 
{
  var divToPrint=document.getElementById('DivIdToPrint');
  var newWin=window.open('','Print-Window');
  newWin.document.open();
  newWin.document.write('<html><body onload="window.print()">'+divToPrint.innerHTML+'</body></html>');
  newWin.document.close();
  setTimeout(function(){newWin.close();},10);
}
  </script>
  <!-- handling data -->
  <script>
	$(document).ready(function(){
		$('#statistics').on('click', function(){
			$('#dd').show(1000);
		});
	});
</script>